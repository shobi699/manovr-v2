"use server";

import { revalidatePath } from "next/cache";
import fs from "fs";
import path from "path";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { hasPerm } from "@/lib/perms";
import { performBackup } from "@/lib/backup";
import { audit } from "@/lib/audit";

/**
 * بررسی دسترسی ادمین/مدیر پشتیبان‌گیری
 */
async function checkAuth() {
  const session = await getSession();
  if (!session) return false;
  if (session.role === 1) return true; // ادمین کل سیستم
  return await hasPerm(session, "settings.global");
}

/**
 * دریافت لیست نسخه‌های پشتیبان
 */
export async function getBackupsList() {
  if (!(await checkAuth())) {
    throw new Error("دسترسی غیرمجاز");
  }

  const list = await prisma.backup.findMany({
    orderBy: { createdAt: "desc" },
  });

  // بررسی وضعیت وجود فیزیکی فایل‌ها روی دیسک
  return list.map((b) => {
    let filePaths;
    try {
      filePaths = JSON.parse(b.filePath);
    } catch {
      filePaths = { db: "", app: "" };
    }

    const dbExists = fs.existsSync(filePaths.db);
    const appExists = fs.existsSync(filePaths.app);

    return {
      ...b,
      dbExists,
      appExists,
    };
  });
}

/**
 * شروع پشتیبان‌گیری دستی
 */
export async function triggerManualBackup() {
  if (!(await checkAuth())) {
    return { error: "دسترسی غیرمجاز" };
  }

  try {
    const backup = await performBackup("manual");
    revalidatePath("/admin/backup");
    return { ok: true, id: backup.id };
  } catch (err: any) {
    console.error(err);
    return { error: err.message || "خطا در ایجاد نسخه پشتیبان" };
  }
}

/**
 * حذف فیزیکی و دیتابیسی نسخه پشتیبان
 */
export async function deleteBackup(id: number) {
  if (!(await checkAuth())) {
    return { error: "دسترسی غیرمجاز" };
  }

  try {
    const backup = await prisma.backup.findUnique({ where: { id } });
    if (!backup) return { error: "پشتیبان یافت نشد" };

    let filePaths;
    try {
      filePaths = JSON.parse(backup.filePath);
    } catch {
      filePaths = { db: "", app: "" };
    }

    // حذف فیزیکی فایل‌ها
    if (fs.existsSync(filePaths.db)) fs.unlinkSync(filePaths.db);
    if (fs.existsSync(filePaths.app)) fs.unlinkSync(filePaths.app);

    // حذف از دیتابیس
    await prisma.backup.delete({ where: { id } });

    // ثبت در لاگ سیستم
    await audit(
      null,
      "backup",
      id,
      "DELETE",
      null,
      {},
      `نسخه پشتیبان به شماره شناسه ${id} حذف شد.`
    );

    revalidatePath("/admin/backup");
    return { ok: true };
  } catch (err: any) {
    console.error(err);
    return { error: err.message || "خطا در حذف نسخه پشتیبان" };
  }
}

/**
 * دریافت تنظیمات زمان‌بندی پشتیبان‌گیری
 */
export async function getBackupSettings() {
  if (!(await checkAuth())) {
    throw new Error("دسترسی غیرمجاز");
  }

  const setting = await prisma.appSetting.findUnique({
    where: { scope_userId_key: { scope: "global", userId: 0, key: "backup_config" } },
  });

  if (!setting) {
    return {
      isEnabled: false,
      schedule: "daily",
      time: "02:00",
    };
  }

  try {
    return JSON.parse(setting.value);
  } catch {
    return {
      isEnabled: false,
      schedule: "daily",
      time: "02:00",
    };
  }
}

/**
 * بروزرسانی تنظیمات زمان‌بندی پشتیبان‌گیری
 */
export async function updateBackupSettings(data: {
  isEnabled: boolean;
  schedule: "daily" | "weekly" | "monthly";
  time: string;
}) {
  if (!(await checkAuth())) {
    return { error: "دسترسی غیرمجاز" };
  }

  try {
    await prisma.appSetting.upsert({
      where: { scope_userId_key: { scope: "global", userId: 0, key: "backup_config" } },
      create: {
        scope: "global",
        userId: 0,
        key: "backup_config",
        value: JSON.stringify(data),
      },
      update: {
        value: JSON.stringify(data),
      },
    });

    // ثبت در لاگ سیستم
    await audit(
      null,
      "backup_config",
      0,
      "UPDATE",
      null,
      data,
      `تنظیمات زمان‌بندی پشتیبان‌گیری بروزرسانی شد: وضعیت ${data.isEnabled ? 'فعال' : 'غیرفعال'}، دوره ${data.schedule}، ساعت ${data.time}`
    );

    revalidatePath("/admin/backup");
    return { ok: true };
  } catch (err: any) {
    console.error(err);
    return { error: err.message || "خطا در ذخیره تنظیمات" };
  }
}
