import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { getSession } from "@/lib/auth";
import { hasPerm } from "@/lib/perms";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || (session.role !== 1 && !(await hasPerm(session, "settings.global")))) {
      return new NextResponse("دسترسی غیرمجاز", { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const id = parseInt(searchParams.get("id") || "");
    const fileType = searchParams.get("type"); // "db" | "app"

    if (isNaN(id) || !fileType) {
      return new NextResponse("پارامترهای نامعتبر", { status: 400 });
    }

    const backup = await prisma.backup.findUnique({ where: { id } });
    if (!backup) {
      return new NextResponse("پشتیبان یافت نشد", { status: 404 });
    }

    let filePaths;
    try {
      filePaths = JSON.parse(backup.filePath);
    } catch {
      filePaths = { db: "", app: "" };
    }

    const targetPath = fileType === "db" ? filePaths.db : filePaths.app;

    if (!fs.existsSync(targetPath)) {
      return new NextResponse("فایل روی سرور وجود ندارد یا حذف شده است", { status: 404 });
    }

    const fileBuffer = fs.readFileSync(targetPath);
    const filename = path.basename(targetPath);

    return new NextResponse(fileBuffer, {
      headers: {
        "Content-Type": fileType === "db" ? "application/octet-stream" : "application/zip",
        "Content-Disposition": `attachment; filename="${encodeURIComponent(filename)}"`,
      },
    });
  } catch (err: any) {
    console.error(err);
    return new NextResponse(err.message || "خطای سرور", { status: 500 });
  }
}
