import React from "react";
import { getBackupsList, getBackupSettings } from "@/app/actions/backup";
import BackupClient from "./BackupClient";

export default async function BackupPage() {
  const backups = await getBackupsList();
  const settings = await getBackupSettings();

  return (
    <div>
      <div className="topbar">
        <h1>پشتیبان‌گیری و امنیت داده‌ها</h1>
      </div>
      <div className="content">
        <BackupClient initialBackups={backups} initialSettings={settings} />
      </div>
    </div>
  );
}
