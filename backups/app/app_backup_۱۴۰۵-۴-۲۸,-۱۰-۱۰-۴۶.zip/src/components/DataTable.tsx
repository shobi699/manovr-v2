"use client";

import React, { useState, useEffect } from "react";
import { saveSetting } from "@/app/actions/settings";
import { Icons } from "@/lib/icons";

interface Column<T> {
  key: string;
  label: string;
  sortable?: boolean;
  render?: (item: T) => React.ReactNode;
}

interface DataTableProps<T> {
  tableName: string;
  columns: Column<T>[];
  data: T[];
  searchPlaceholder?: string;
  searchFields?: (keyof T)[];
  initialHiddenColumns?: string[];
}

export default function DataTable<T extends Record<string, any>>({
  tableName,
  columns,
  data,
  searchPlaceholder = "جستجو...",
  searchFields = [],
  initialHiddenColumns = [],
}: DataTableProps<T>) {
  const [search, setSearch] = useState("");
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [hiddenCols, setHiddenCols] = useState<string[]>(initialHiddenColumns);
  const [showConfig, setShowConfig] = useState(false);

  // لود ستون‌های مخفی از لوکال استوریج یا تنظیمات برای لود سریع‌تر (به عنوان fallback)
  useEffect(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem(`dt.hidden.${tableName}`);
      if (saved) {
        try {
          setHiddenCols(JSON.parse(saved));
        } catch {}
      }
    }
  }, [tableName]);

  const handleToggleCol = async (colKey: string) => {
    const isHidden = hiddenCols.includes(colKey);
    const updated = isHidden
      ? hiddenCols.filter((k) => k !== colKey)
      : [...hiddenCols, colKey];

    setHiddenCols(updated);
    if (typeof window !== "undefined") {
      localStorage.setItem(`dt.hidden.${tableName}`, JSON.stringify(updated));
    }
    // ذخیره در سرور به عنوان AppSetting
    await saveSetting(`table.hidden.${tableName}`, updated);
  };

  const handleSort = (colKey: string) => {
    if (sortCol === colKey) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortCol(colKey);
      setSortDir("asc");
    }
  };

  // فیلتر داده‌ها
  const filtered = data.filter((item) => {
    if (!search || searchFields.length === 0) return true;
    const term = search.toLowerCase();
    return searchFields.some((field) => {
      const val = item[field];
      if (val === undefined || val === null) return false;
      return String(val).toLowerCase().includes(term);
    });
  });

  // مرتب‌سازی
  const sorted = [...filtered].sort((a, b) => {
    if (!sortCol) return 0;
    let valA = a[sortCol];
    let valB = b[sortCol];

    if (valA === undefined || valA === null) return 1;
    if (valB === undefined || valB === null) return -1;

    if (typeof valA === "string") {
      return sortDir === "asc"
        ? valA.localeCompare(valB)
        : valB.localeCompare(valA);
    }
    return sortDir === "asc"
      ? (valA > valB ? 1 : -1)
      : (valA < valB ? 1 : -1);
  });

  // صفحه‌بندی
  const totalPages = Math.ceil(sorted.length / pageSize);
  const paginated = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  useEffect(() => {
    setCurrentPage(1);
  }, [search, sortCol, sortDir, pageSize]);

  const activeColumns = columns.filter((col) => !hiddenCols.includes(col.key));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      {/* هدر کنترل جدول */}
      <div className="toolbar" style={{ justifyContent: "space-between" }}>
        {searchFields.length > 0 ? (
          <input
            type="text"
            placeholder={searchPlaceholder}
            className="input search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ maxWidth: "300px" }}
          />
        ) : (
          <div />
        )}

        <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
          {/* انتخابگر تعداد صفحات */}
          <select
            className="input"
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            style={{ width: "90px", padding: "6px 8px", fontSize: "12px" }}
          >
            <option value="5">۵ ردیف</option>
            <option value="10">۱۰ ردیف</option>
            <option value="20">۲۰ ردیف</option>
            <option value="50">۵۰ ردیف</option>
          </select>

          {/* شخصی‌سازی ستون‌ها */}
          <div style={{ position: "relative" }}>
            <button
              type="button"
              className="btn sm"
              onClick={() => setShowConfig(!showConfig)}
              style={{ padding: "8px 12px", fontSize: "13px", display: "inline-flex", alignItems: "center", gap: "6px" }}
            >
              <Icons.Lines size={14} weight="bold" />
              <span>ستون‌ها</span>
            </button>
            {showConfig && (
              <div
                style={{
                  position: "absolute",
                  top: "38px",
                  left: 0,
                  backgroundColor: "var(--panel)",
                  border: "1px solid var(--line)",
                  borderRadius: "8px",
                  padding: "10px",
                  zIndex: 10,
                  width: "180px",
                  boxShadow: "var(--sh-2)",
                }}
              >
                <div style={{ fontSize: "12px", fontWeight: "bold", marginBottom: "8px", borderBottom: "1px solid var(--line)", paddingBottom: "4px" }}>
                  انتخاب ستون‌های نمایشی
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {columns.map((col) => (
                    <label
                      key={col.key}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "6px",
                        fontSize: "12px",
                        cursor: "pointer",
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={!hiddenCols.includes(col.key)}
                        onChange={() => handleToggleCol(col.key)}
                        style={{ accentColor: "var(--accent)" }}
                      />
                      {col.label}
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* بخش جدول داده */}
      <div className="card tbl-wrap">
        <table className="data">
          <thead>
            <tr>
              {activeColumns.map((col) => (
                <th
                  key={col.key}
                  onClick={() => col.sortable && handleSort(col.key)}
                  style={{
                    cursor: col.sortable ? "pointer" : "default",
                    userSelect: "none",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                    {col.label}
                    {col.sortable && sortCol === col.key && (
                      <span style={{ fontSize: "10px" }}>{sortDir === "asc" ? "▲" : "▼"}</span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={activeColumns.length} className="empty">
                  داده‌ای جهت نمایش یافت نشد.
                </td>
              </tr>
            ) : (
              paginated.map((item, idx) => (
                <tr key={item.id ?? idx}>
                  {activeColumns.map((col) => (
                    <td key={col.key}>
                      {col.render ? col.render(item) : item[col.key] ?? "—"}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* بخش صفحه‌بندی */}
      {totalPages > 1 && (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "4px" }}>
          <div className="muted" style={{ fontSize: "12px" }}>
            نمایش {(currentPage - 1) * pageSize + 1} تا {Math.min(currentPage * pageSize, sorted.length)} از {sorted.length} ردیف
          </div>
          <div style={{ display: "flex", gap: "6px" }}>
            <button
              className="btn sm"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => p - 1)}
            >
              قبلی
            </button>
            <span style={{ alignSelf: "center", fontSize: "13px", padding: "0 10px" }} className="num">
              صفحه {currentPage} از {totalPages}
            </span>
            <button
              className="btn sm"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage((p) => p + 1)}
            >
              بعدی
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
