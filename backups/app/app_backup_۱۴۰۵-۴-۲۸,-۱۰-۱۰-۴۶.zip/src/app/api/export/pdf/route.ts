import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { hasPerm } from "@/lib/perms";
import { runDynamicReport } from "@/app/actions/report";
import { generatePDFBuffer } from "@/lib/export-helpers";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || !(await hasPerm(session, "report.export"))) {
    return new NextResponse("عدم دسترسی", { status: 403 });
  }

  const config = await req.json();
  const res = await runDynamicReport(config);
  if (res.error || !res.records) {
    return new NextResponse(res.error || "خطا در دریافت داده‌ها", { status: 400 });
  }

  const buffer = await generatePDFBuffer(config.entity, config.fields, res.records);

  return new NextResponse(buffer as any, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="depot-report-${config.entity}.pdf"`,
    },
  });
}
