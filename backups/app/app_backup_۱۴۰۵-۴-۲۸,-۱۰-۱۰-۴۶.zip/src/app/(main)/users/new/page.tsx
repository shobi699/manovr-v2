import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { hasPerm } from "@/lib/perms";
import { redirect } from "next/navigation";
import NewUserForm from "./NewUserForm";

export default async function NewUserPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const currentUser = await prisma.personnel.findUnique({
    where: { id: session.id },
  });
  const hasManagePerm = await hasPerm(session, "user.manage");
  const isShiftSupervisor = currentUser?.orgPosition === 2;

  if (!hasManagePerm && !isShiftSupervisor) redirect("/users");

  const roles = await prisma.accessRole.findMany({
    orderBy: { name: "asc" },
  });

  const serializableUser = currentUser ? {
    id: currentUser.id,
    shift: currentUser.shift,
    orgPosition: currentUser.orgPosition,
    personnelType: currentUser.personnelType,
  } : null;

  return (
    <>
      <div className="topbar"><h1>افزودن کاربر جدید</h1></div>
      <div className="content">
        <div className="card">
          <div className="card-body">
            <NewUserForm roles={roles} currentUser={serializableUser} />
          </div>
        </div>
      </div>
    </>
  );
}
