"use client";

import React, { useState } from "react";
import DataTable from "@/components/DataTable";
import UserRowActions from "./UserRowActions";
import { Role, OrgPosition, Shift, PersonnelType, ManovrType, ManovrStatus, ConfirmationStatus } from "@/lib/enums";
import { importPersonnelFromExcel } from "@/app/actions/user";

interface UsersTableClientProps {
  accounts: any[];
  nonAccounts: any[];
  canManage: boolean;
  currentUserId: number;
  isShiftSupervisor?: boolean;
  todayManeuvers?: any[];
}

export default function UsersTableClient({
  accounts,
  nonAccounts,
  canManage,
  currentUserId,
  isShiftSupervisor = false,
  todayManeuvers = [],
}: UsersTableClientProps) {
  const [activeTab, setActiveTab] = useState<"personnel" | "maneuvers">("personnel");

  const handleExportExcel = async () => {
    try {
      const ExcelJS = (await import("exceljs")).default;
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("لیست پرسنل");
      worksheet.views = [{ rtl: true } as any];

      worksheet.columns = [
        { header: "نام", key: "firstName", width: 15 },
        { header: "نام خانوادگی", key: "lastName", width: 15 },
        { header: "کد پرسنلی", key: "personnelCode", width: 15 },
        { header: "نام کاربری", key: "userName", width: 15 },
        { header: "شیفت", key: "shift", width: 10 },
        { header: "پست سازمانی", key: "orgPosition", width: 15 },
        { header: "نوع پرسنل", key: "personnelType", width: 15 },
        { header: "همراه ۱", key: "phone1", width: 15 },
        { header: "همراه ۲", key: "phone2", width: 15 },
        { header: "تلفن داخلی", key: "internalTel", width: 12 },
        { header: "آدرس منزل", key: "address", width: 30 },
      ];

      const allData = [...accounts, ...nonAccounts];
      allData.forEach((p) => {
        worksheet.addRow({
          firstName: p.firstName,
          lastName: p.lastName,
          personnelCode: p.personnelCode || "—",
          userName: p.userName || "—",
          shift: Shift[p.shift] || p.shift,
          orgPosition: OrgPosition[p.orgPosition] || p.orgPosition,
          personnelType: PersonnelType[p.personnelType] || p.personnelType,
          phone1: p.phone1 || "—",
          phone2: p.phone2 || "—",
          internalTel: p.internalTel || "—",
          address: p.address || "—",
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "personnel-list.xlsx";
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);
      alert("خطا در خروجی گرفتن اکسل.");
    }
  };

  const handleDownloadSample = async () => {
    try {
      const ExcelJS = (await import("exceljs")).default;
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("نمونه ورود پرسنل");
      worksheet.views = [{ rtl: true } as any];

      worksheet.columns = [
        { header: "نام *", key: "firstName", width: 15 },
        { header: "نام خانوادگی *", key: "lastName", width: 15 },
        { header: "کد پرسنلی (یکتا)", key: "personnelCode", width: 15 },
        { header: "نام کاربری", key: "userName", width: 15 },
        { header: "همراه ۱", key: "phone1", width: 15 },
        { header: "همراه ۲", key: "phone2", width: 15 },
        { header: "داخلی پایانه", key: "internalTel", width: 12 },
        { header: "آدرس منزل", key: "address", width: 30 },
        { header: "شیفت (1=A, 2=B, 3=C)", key: "shift", width: 12 },
        { header: "سمت (1=راهبر، 2=مسئول شیفت، 4=تکنیسین، 5=سایر)", key: "orgPosition", width: 25 },
      ];

      worksheet.addRow({
        firstName: "علی",
        lastName: "رضایی",
        personnelCode: "99101",
        userName: "ali99",
        phone1: "09123456789",
        phone2: "",
        internalTel: "123",
        address: "تهران، میدان آزادی",
        shift: 1,
        orgPosition: 1,
      });

      worksheet.addRow({
        firstName: "حسین",
        lastName: "کریمی",
        personnelCode: "99102",
        userName: "",
        phone1: "09901234567",
        phone2: "",
        internalTel: "124",
        address: "تهران، خیابان ولیعصر",
        shift: 2,
        orgPosition: 4,
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "personnel-sample.xlsx";
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);
      alert("خطا در تولید فایل نمونه اکسل.");
    }
  };

  const handleExcelImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const arrayBuffer = event.target?.result as ArrayBuffer;
        const ExcelJS = (await import("exceljs")).default;
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(arrayBuffer);
        const worksheet = workbook.worksheets[0];

        const rows: any[] = [];
        worksheet.eachRow((row, rowNumber) => {
          if (rowNumber === 1) return; // skip header
          const vals = Array.isArray(row.values) ? row.values : [];
          
          const firstName = String(vals[1] || "").trim();
          const lastName = String(vals[2] || "").trim();
          if (!firstName || !lastName) return;

          const personnelCode = vals[3] ? String(vals[3]).trim() : undefined;
          const userName = vals[4] ? String(vals[4]).trim() : undefined;
          const phone1 = vals[5] ? String(vals[5]).trim() : undefined;
          const phone2 = vals[6] ? String(vals[6]).trim() : undefined;
          const internalTel = vals[7] ? String(vals[7]).trim() : undefined;
          const address = vals[8] ? String(vals[8]).trim() : undefined;
          const shift = vals[9] ? Number(vals[9]) : undefined;
          const orgPosition = vals[10] ? Number(vals[10]) : undefined;

          rows.push({
            firstName,
            lastName,
            personnelCode,
            userName,
            phone1,
            phone2,
            internalTel,
            address,
            shift,
            orgPosition,
          });
        });

        if (rows.length === 0) {
          alert("هیچ داده معتبری در فایل پیدا نشد.");
          return;
        }

        const res = await importPersonnelFromExcel(rows);
        if (res.error) {
          alert(res.error);
        } else {
          alert(`تعداد ${res.count} پرسنل جدید با موفقیت درج شدند.`);
          window.location.reload();
        }
      } catch (err) {
        console.error(err);
        alert("فرمت فایل اکسل معتبر نیست یا خطا در خواندن رخ داد.");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const rolePill = (r: number) =>
    r === 1 ? "p-crit" : r === 2 ? "p-warn" : r === 3 ? "p-rail" : "p-mut";

  const accountColumns = [
    { key: "userName", label: "نام کاربری", sortable: true, render: (p: any) => <span className="num">{p.userName}</span> },
    { key: "fullName", label: "نام و نام خانوادگی", sortable: true, render: (p: any) => `${p.firstName} ${p.lastName}` },
    { key: "personnelCode", label: "کد پرسنلی", sortable: true, render: (p: any) => <span className="num">{p.personnelCode || "—"}</span> },
    {
      key: "role",
      label: "نقش دسترسی",
      sortable: true,
      render: (p: any) => (
        <span className={`pill ${rolePill(p.role)}`}>
          {p.accessRole?.name || Role[p.role]}
        </span>
      ),
    },
    { key: "orgPosition", label: "پست سازمانی", sortable: true, render: (p: any) => OrgPosition[p.orgPosition] },
    { key: "shift", label: "شیفت", sortable: true, render: (p: any) => <span className="num">{Shift[p.shift]}</span> },
    {
      key: "personnelType",
      label: "نوع پرسنل",
      sortable: true,
      render: (p: any) => (
        <span className="pill p-mut">{PersonnelType[p.personnelType] ?? "—"}</span>
      ),
    },
    ...(canManage
      ? [
          {
            key: "actions",
            label: "عملیات",
            render: (p: any) => <UserRowActions id={p.id} currentUserId={currentUserId} />,
          },
        ]
      : []),
  ];

  const nonAccountColumns = [
    { key: "fullName", label: "نام و نام خانوادگی", sortable: true, render: (p: any) => `${p.firstName} ${p.lastName}` },
    { key: "personnelCode", label: "کد پرسنلی", sortable: true, render: (p: any) => <span className="num">{p.personnelCode || "—"}</span> },
    { key: "orgPosition", label: "پست سازمانی", sortable: true, render: (p: any) => OrgPosition[p.orgPosition] },
    { key: "shift", label: "شیفت", sortable: true, render: (p: any) => <span className="num">{Shift[p.shift]}</span> },
    {
      key: "personnelType",
      label: "نوع پرسنل",
      sortable: true,
      render: (p: any) => (
        <span className="pill p-mut">{PersonnelType[p.personnelType] ?? "—"}</span>
      ),
    },
    ...(canManage
      ? [
          {
            key: "actions",
            label: "عملیات",
            render: (p: any) => <UserRowActions id={p.id} currentUserId={currentUserId} />,
          },
        ]
      : []),
  ];

  const maneuverColumns = [
    { key: "id", label: "شناسه", sortable: true, render: (m: any) => <span className="num">{m.id}</span> },
    {
      key: "executionTime",
      label: "زمان اجرا",
      sortable: true,
      render: (m: any) => (
        <span className="num" dir="ltr">
          {new Date(m.executionTime || m.createdAt).toLocaleString("fa-IR", {
            timeZone: "Asia/Tehran",
            dateStyle: "short",
            timeStyle: "short",
          })}
        </span>
      ),
    },
    { key: "type", label: "نوع مانور", sortable: true, render: (m: any) => ManovrType[m.type] || m.type },
    { key: "train", label: "قطار", sortable: true, render: (m: any) => m.train ? <span className="num">{m.train.code}</span> : "—" },
    { key: "sourceLine", label: "خط مبدأ", sortable: true, render: (m: any) => m.sourceLine?.name || "—" },
    { key: "destinationLine", label: "خط مقصد", sortable: true, render: (m: any) => m.destinationLine?.name || "—" },
    { key: "rahbar1", label: "راهبر ۱", sortable: true, render: (m: any) => m.rahbar1 ? `${m.rahbar1.firstName} ${m.rahbar1.lastName}` : "—" },
    { key: "rahbar2", label: "راهبر ۲", sortable: true, render: (m: any) => m.rahbar2 ? `${m.rahbar2.firstName} ${m.rahbar2.lastName}` : "—" },
    {
      key: "status",
      label: "وضعیت",
      sortable: true,
      render: (m: any) => (
        <span className={`pill ${m.status === 2 ? "p-good" : m.status === 3 ? "p-crit" : "p-warn"}`}>
          {ManovrStatus[m.status] || m.status}
        </span>
      ),
    },
    {
      key: "confirmationStatus",
      label: "تأییدیه",
      sortable: true,
      render: (m: any) => (
        <span className={`pill ${m.confirmationStatus === 1 ? "p-good" : m.confirmationStatus === 2 ? "p-crit" : "p-mut"}`}>
          {ConfirmationStatus[m.confirmationStatus] || m.confirmationStatus}
        </span>
      ),
    },
  ];

  return (
    <>
      {isShiftSupervisor && (
        <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
          <button
            onClick={() => setActiveTab("personnel")}
            className={`btn ${activeTab === "personnel" ? "primary" : ""}`}
            style={{ borderRadius: "var(--r-sm)" }}
          >
            پرسنل شیفت
          </button>
          <button
            onClick={() => setActiveTab("maneuvers")}
            className={`btn ${activeTab === "maneuvers" ? "primary" : ""}`}
            style={{ borderRadius: "var(--r-sm)" }}
          >
            مانورهای امروز شیفت ({todayManeuvers.length})
          </button>
        </div>
      )}

      {activeTab === "personnel" ? (
        <>
          {canManage && (
            <div className="card" style={{ padding: "16px", marginBottom: "20px", display: "flex", flexWrap: "wrap", gap: "12px", alignItems: "center" }}>
              <span style={{ fontWeight: 600, fontSize: "14px", color: "var(--ink)" }}>عملیات گروهی اکسل:</span>
              
              <button onClick={handleExportExcel} className="btn primary sm" style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <span style={{ fontSize: "16px" }}>📥</span> خروجی اکسل پرسنل
              </button>
              
              <label className="btn sm" style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: "6px", margin: 0, padding: "8px 12px", border: "1px solid var(--line)" }}>
                <span style={{ fontSize: "16px" }}>📤</span> بارگذاری اکسل پرسنل
                <input type="file" accept=".xlsx" onChange={handleExcelImport} style={{ display: "none" }} />
              </label>
              
              <button onClick={handleDownloadSample} className="btn sm" style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "transparent", border: "1px dashed var(--line)" }}>
                <span style={{ fontSize: "16px" }}>📄</span> دانلود نمونه اکسل ورودی
              </button>
            </div>
          )}

          {/* لیست حساب‌های فعال */}
          <div className="card" style={{ padding: "16px" }}>
            <div className="card-head" style={{ padding: "0 0 12px 0", borderBottom: "1px solid var(--line)" }}>
              <h2>حساب‌های کاربری فعال</h2>
              <span className="spacer" />
              <span className="pill p-mut">{accounts.length} حساب</span>
            </div>
            <div style={{ marginTop: "14px" }}>
              <DataTable
                tableName="user_accounts"
                columns={accountColumns}
                data={accounts}
                searchPlaceholder="جستجو بر اساس نام کاربری، نام یا نام خانوادگی..."
                searchFields={["userName", "firstName", "lastName"]}
              />
            </div>
          </div>

          {/* لیست پرسنل بدون حساب */}
          <div className="card" style={{ marginTop: 24, padding: "16px" }}>
            <div className="card-head" style={{ padding: "0 0 12px 0", borderBottom: "1px solid var(--line)" }}>
              <h2>پرسنل بدون حساب کاربری</h2>
              <span className="spacer" />
              <span className="pill p-mut">{nonAccounts.length} پرسنل</span>
            </div>
            <div style={{ marginTop: "14px" }}>
              <DataTable
                tableName="user_personnel"
                columns={nonAccountColumns}
                data={nonAccounts}
                searchPlaceholder="جستجو بر اساس نام یا نام خانوادگی..."
                searchFields={["firstName", "lastName"]}
              />
            </div>
          </div>
        </>
      ) : (
        <div className="card" style={{ padding: "16px" }}>
          <div className="card-head" style={{ padding: "0 0 12px 0", borderBottom: "1px solid var(--line)" }}>
            <h2>مانورهای ثبت شده امروز شیفت</h2>
            <span className="spacer" />
            <span className="pill p-mut">{todayManeuvers.length} مانور</span>
          </div>
          <div style={{ marginTop: "14px" }}>
            <DataTable
              tableName="shift_today_maneuvers"
              columns={maneuverColumns}
              data={todayManeuvers}
              searchPlaceholder="جستجو بر اساس قطار، نوع مانور..."
              searchFields={["train.code", "type"]}
            />
          </div>
        </div>
      )}
    </>
  );
}
