"use client";

import React, { useState, useEffect, useRef, useTransition, useMemo } from "react";
import { useRouter } from "next/navigation";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Html, ContactShadows, Environment, Grid } from "@react-three/drei";
import * as THREE from "three";
import { Terminal as TerminalEnum, TrainType, ManovrType } from "@/lib/enums";
import { createManovr } from "@/app/actions/manovr";
import { saveLinePositions, toggleLineActive } from "@/app/actions/line";
import { relocateTrainDirectly, updateTrainStatus } from "@/app/actions/train";
import { useTheme } from "@/components/ThemeProvider";
import JalaliDateTimePicker from "@/components/JalaliDateTimePicker";
import { useLiveRefresh } from "@/hooks/useLiveRefresh";

import IndustrialShed from "./scene3d/Shed";
import TrainModel3D from "./scene3d/TrainModel";
import { ZONE_CONFIG, STATUS_STYLE } from "@/lib/depot-visuals";
import { Icons } from "@/lib/icons";
import SearchableSelect from "@/components/SearchableSelect";
import { BorderRotate } from "@/components/ui/animated-gradient-border";


// کامپوننت هدایت دوربین سه‌بعدی برای زوم روی سوله‌ها
function CameraDirector({
  focusTarget,
  controlsRef,
}: {
  focusTarget: [number, number, number] | null;
  controlsRef: React.MutableRefObject<any>;
}) {
  const { camera, invalidate } = useThree();

  useFrame(() => {
    if (focusTarget && controlsRef.current) {
      const targetVec = new THREE.Vector3(...focusTarget);
      const currentTarget = controlsRef.current.target;
      const distTarget = currentTarget.distanceTo(targetVec);

      const targetCamPos = new THREE.Vector3(focusTarget[0], focusTarget[1] + 60, focusTarget[2] + 75);
      const distCam = camera.position.distanceTo(targetCamPos);

      if (distTarget > 0.05 || distCam > 0.05) {
        controlsRef.current.target.x = THREE.MathUtils.lerp(controlsRef.current.target.x, focusTarget[0], 0.08);
        controlsRef.current.target.y = THREE.MathUtils.lerp(controlsRef.current.target.y, focusTarget[1], 0.08);
        controlsRef.current.target.z = THREE.MathUtils.lerp(controlsRef.current.target.z, focusTarget[2], 0.08);

        camera.position.x = THREE.MathUtils.lerp(camera.position.x, focusTarget[0], 0.05);
        camera.position.y = THREE.MathUtils.lerp(camera.position.y, focusTarget[1] + 60, 0.05);
        camera.position.z = THREE.MathUtils.lerp(camera.position.z, focusTarget[2] + 75, 0.05);

        controlsRef.current.update();
        invalidate();
      }
    }
  });

  return null;
}

interface LineData {
  id: number;
  name: string;
  tag: string | null;
  capacity: number;
  terminal: number;
  isDynamic: boolean;
  posX: number;
  posY: number;
  rotation: number;
  length: number;
}

interface TrainData {
  id: number;
  code: string;
  type: number;
  isDisposed: boolean;
  lineId: number | null;
  slotIndex: number;
  status: number;
}

interface DepotSceneProps {
  lines: LineData[];
  initialTrains: TrainData[];
  activeManovrs: { id: number; trainId: number | null; destinationLineId: number | null }[];
  rahbaran: { id: number; name: string }[];
  terminals: { id: number; code: number; label: string; color: string | null; meta: string }[];
  canLayout: boolean;
  canCreateManovr: boolean;
  canManageLines: boolean;
  prefs: { quality: string; refreshSec: number; defaultTerminal: number };
}

// ----------------------------------------------------
// کامپوننت‌های فرعی صحنه سه‌بعدی
// ----------------------------------------------------

function CameraController({ defaultTerminal, lines, zones }: { defaultTerminal: number; lines: LineData[]; zones: any }) {
  const { camera } = useThree();

  useEffect(() => {
    // دوربین به سمت ترمینال پیش‌فرض هدایت می‌شود
    if (defaultTerminal > 0 && zones[defaultTerminal]) {
      const zone = zones[defaultTerminal];
      camera.position.set(zone.x, 90, zone.z + 130);
      camera.lookAt(new THREE.Vector3(zone.x, 0, zone.z));
    } else {
      // نمای کلی — قاب‌گیری کل چیدمان (X از ~-580 تا ~+580)
      camera.position.set(0, 380, 420);
      camera.lookAt(new THREE.Vector3(0, 0, 0));
    }
  }, [defaultTerminal, camera, zones]);

  return null;
}



// ----------------------------------------------------
// کامپوننت اصلی کلاینت‌ساید دپو
// ----------------------------------------------------

export default function DepotScene({
  lines,
  initialTrains,
  activeManovrs,
  rahbaran,
  terminals,
  canLayout,
  canCreateManovr,
  canManageLines,
  prefs,
}: DepotSceneProps) {
  const router = useRouter();

  // ساخت پویای مختصات و پیکربندی زون‌ها بر اساس ترمینال‌های دیتابیس
  const ZONES = useMemo(() => {
    const map: Record<number, { x: number; z: number; label: string; color: string; gridCol: number; gridRow: "top" | "bottom" | "full" }> = {};
    terminals.forEach((t) => {
      let meta: any = {};
      try {
        meta = JSON.parse(t.meta || "{}");
      } catch {}
      map[t.code] = {
        x: typeof meta.x === "number" ? meta.x : 0,
        z: typeof meta.z === "number" ? meta.z : 0,
        label: t.label,
        color: t.color || "#cbd5e1",
        gridCol: typeof meta.gridCol === "number" ? meta.gridCol : 1,
        gridRow: meta.gridRow || "full",
      };
    });
    return map;
  }, [terminals]);

  // گروه‌بندی پایانه بر اساس ستون‌های ۲بعدی
  const columnsData = useMemo(() => {
    const cols: Record<number, any[]> = { 1: [], 2: [], 3: [], 4: [], 5: [] };
    terminals.forEach((t) => {
      let meta: any = {};
      try {
        meta = JSON.parse(t.meta || "{}");
      } catch {}
      const colIdx = typeof meta.gridCol === "number" ? meta.gridCol : 1;
      const row = meta.gridRow || "full";
      
      if (!cols[colIdx]) cols[colIdx] = [];
      cols[colIdx].push({ ...t, gridRow: row, metaParsed: meta });
    });
    
    // مرتب‌سازی هر ستون: ابتدا ردیف‌های top، سپس full، سپس bottom
    for (const c in cols) {
      cols[c].sort((a, b) => {
        const order: Record<string, number> = { top: 1, full: 2, bottom: 3 };
        return (order[a.gridRow] || 2) - (order[b.gridRow] || 2);
      });
    }
    return cols;
  }, [terminals]);
  useLiveRefresh(["manovr_changed", "train_changed"]);
  const { appearance } = useTheme();
  const [isPending, startTransition] = useTransition();
  const [trains, setTrains] = useState<TrainData[]>(initialTrains);
  const [selectedTrain, setSelectedTrain] = useState<TrainData | null>(null);
  const [selectedLine, setSelectedLine] = useState<LineData | null>(null);
  const [hoveredLineId, setHoveredLineId] = useState<number | null>(null);

  // سیستم زوم و فوکوس دوربین روی سوله‌ها
  const [cameraFocusTarget, setCameraFocusTarget] = useState<[number, number, number] | null>(null);
  const controlsRef = useRef<any>(null);

  // سیستم مدیریت تب و مشخصات مانور روی خطوط ریل
  const [activeLineTab, setActiveLineTab] = useState<"details" | "manovr" | "relocate">("details");
  const [manovrTrainId, setManovrTrainId] = useState<number | "">("");
  const [manovrSourceLineId, setManovrSourceLineId] = useState<number | "">("");
  const [manovrDestLineId, setManovrDestLineId] = useState<number | "">("");
  const [manovrSlotIdx, setManovrSlotIdx] = useState<number>(0);
  const [manovrRahbar1, setManovrRahbar1] = useState<number | "">("");
  const [manovrRahbar2, setManovrRahbar2] = useState<number | "">("");
  const [manovrType, setManovrType] = useState<number>(2);
  const [manovrDesc, setManovrDesc] = useState<string>("");

  // فیلدهای جابجایی سریع ادمین
  const [relocateTrainId, setRelocateTrainId] = useState<number | "">("");
  const [relocateLineId, setRelocateLineId] = useState<number | "">("");
  const [relocateSlotIdx, setRelocateSlotIdx] = useState<number>(0);
  const [newTrainIdState, setNewTrainIdState] = useState<number | "">("");

  // وضعیت کیفیت و نمای ۲بعدی/۳بعدی جاری
  const [currentQuality, setCurrentQuality] = useState<string>("2d");

  // شناسه قطار پیش‌انتخاب شده برای مودال مانور کشیدن و رها کردن
  const [preSelectedTrainId, setPreSelectedTrainId] = useState<number | "">("");

  // زمان اجرای مانور انتخابی کاربر
  const [manovrExecutionTime, setManovrExecutionTime] = useState<string>(new Date().toISOString());

  // ریست کردن فیلدهای مودال با تغییر ریل انتخابی
  useEffect(() => {
    if (selectedLine) {
      setActiveLineTab("details");
      setManovrTrainId("");
      setManovrSourceLineId(selectedLine.id);
      setManovrDestLineId("");
      setManovrSlotIdx(0);
      setManovrRahbar1("");
      setManovrRahbar2("");
      setManovrType(2);
      setManovrDesc("");
      setManovrExecutionTime(new Date().toISOString());

      setRelocateTrainId("");
      setRelocateLineId(selectedLine.id);
      setRelocateSlotIdx(0);
      setNewTrainIdState("");
    }
  }, [selectedLine]);

  // همگام‌سازی وضعیت قطارها با تغییر پروپس ورودی از سرور
  useEffect(() => {
    setTrains(initialTrains);
  }, [initialTrains]);

  // وضعیت درگ سه‌بعدی
  const [draggedTrainId, setDraggedTrainId] = useState<number | null>(null);
  const [dragPos, setDragPos] = useState<[number, number, number]>([0, 0, 0]);

  // مودال‌ها
  const [showManovrModal, setShowManovrModal] = useState(false);
  const [showLineModal, setShowLineModal] = useState(false);
  const [sourceLineId, setSourceLineId] = useState<number | null>(null);
  const [destLineId, setDestLineId] = useState<number | null>(null);
  const [targetSlot, setTargetSlot] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);

  // تغییرات چیدمان ریل‌ها توسط ادمین
  const [modifiedPositions, setModifiedPositions] = useState<Record<number, { posX: number; posY: number; rotation: number }>>({});
  const [isSavingLayout, setIsSavingLayout] = useState(false);

  // مدیریت رفرش خودکار بر اساس پولینگ
  useEffect(() => {
    if (prefs.refreshSec === 0) return;
    const timer = setInterval(() => {
      startTransition(() => {
        router.refresh();
      });
    }, prefs.refreshSec * 1000);
    return () => clearInterval(timer);
  }, [prefs.refreshSec, router]);

  // رویداد فشردن کیبورد Ctrl+K برای جستجو
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        setShowSearch((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // شروع درگ قطار
  const handleTrainDragStart = (trainId: number, initialPos: [number, number, number]) => {
    if (!canCreateManovr) return;
    setDraggedTrainId(trainId);
    setDragPos(initialPos);
  };

  // رها کردن قطار و باز شدن مودال ثبت مانور
  const handleTrainDragEnd = (lineId: number, slotIdx: number) => {
    if (draggedTrainId === null) return;
    const trainObj = trains.find((t) => t.id === draggedTrainId);
    if (!trainObj) return;

    setSourceLineId(trainObj.lineId);
    setDestLineId(lineId);
    setTargetSlot(slotIdx);
    setPreSelectedTrainId(trainObj.id);
    setShowManovrModal(true);

    setDraggedTrainId(null);
  };

  const handleCreateManovrSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (sourceLineId) fd.append("sourceLineId", String(sourceLineId));
    if (destLineId) fd.append("destinationLineId", String(destLineId));
    fd.append("slotIndex", String(targetSlot));

    const res = await createManovr(null, fd);
    if (res?.error) {
      alert(res.error);
    } else {
      setShowManovrModal(false);
      router.refresh();
    }
  };

  // ذخیره چیدمان ریل‌ها پس از درگ در حالت ادمین
  const handleSaveLayout = async () => {
    setIsSavingLayout(true);
    const payload = Object.entries(modifiedPositions).map(([id, val]) => ({
      id: Number(id),
      posX: val.posX,
      posY: val.posY,
      rotation: val.rotation,
    }));

    const res = await saveLinePositions(payload);
    setIsSavingLayout(false);
    if (res.error) {
      alert(res.error);
    } else {
      setModifiedPositions({});
      alert("چیدمان پایانه با موفقیت در دیتابیس ثبت شد.");
      router.refresh();
    }
  };

  // فیلتر کردن ریل‌ها بر اساس جستجوی کاربر
  const filteredSearchList = useMemo(() => {
    if (!searchQuery) return [];
    const q = searchQuery.toLowerCase();
    const matchesLine = lines.filter((l) => l.name.toLowerCase().includes(q) || (l.tag && l.tag.toLowerCase().includes(q)));
    const matchesTrain = trains.filter((t) => t.code.toLowerCase().includes(q));

    return [
      ...matchesLine.map((l) => ({ type: "line" as const, id: l.id, title: `خط: ${l.name}`, obj: l })),
      ...matchesTrain.map((t) => ({ type: "train" as const, id: t.id, title: `قطار شماره ${t.code}`, obj: t })),
    ];
  }, [searchQuery, lines, trains]);

  const handleSearchResultClick = (item: any) => {
    if (item.type === "train") {
      setSelectedTrain(item.obj);
    } else {
      setSelectedLine(item.obj);
    }
    setShowSearch(false);
    setSearchQuery("");
  };

  // ----------------------------------------------------
  // نمای دوبعدی SVG تعاملی
  // ----------------------------------------------------
  const render2DMap = () => {
    // تابع کمکی برای رندر خانه‌های ریل به صورت ۲بعدی تعاملی
    const renderSlot = (lineName: string, label: string) => {
      const line = lines.find(l => l.name === lineName);
      if (!line) {
        return (
          <div
            key={lineName}
            style={{
              border: "1px dashed var(--line)",
              borderRadius: "var(--r-sm)",
              padding: "4px 8px",
              minHeight: "36px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              fontSize: "11px",
              color: "var(--ink-faint)",
              backgroundColor: "var(--bg)",
            }}
          >
            <span>{label}</span>
            <span>—</span>
          </div>
        );
      }

      const lineTrains = trains.filter(t => t.lineId === line.id && !t.isDisposed).sort((a, b) => a.slotIndex - b.slotIndex);
      const hasTrain = lineTrains.length > 0;
      const train = lineTrains[0];
      const style = hasTrain ? (STATUS_STYLE[train.status] || STATUS_STYLE[1]) : null;
      const isActive = (line as any).isActive !== false;

      if (!isActive) {
        return (
          <div
            key={lineName}
            onClick={() => {
              if (canManageLines) {
                setSelectedLine(line);
                setDestLineId(line.id);
              }
            }}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "6px 12px",
              border: "1px dashed var(--crit)",
              borderRadius: "var(--r-sm)",
              backgroundColor: "color-mix(in oklab, var(--crit) 8%, var(--bg))",
              color: "var(--crit)",
              cursor: canManageLines ? "pointer" : "not-allowed",
              minHeight: "38px",
              opacity: 0.75,
              textDecoration: "line-through",
            }}
            title="این خط توسط مدیر مسدود/غیرفعال شده است"
          >
            <span style={{ fontSize: "11px", fontWeight: "600" }}>{label} (مسدود)</span>
            <span style={{ fontSize: "12px" }}>🚫</span>
          </div>
        );
      }

      return (
        <div
          key={lineName}
          onClick={() => {
            setSelectedLine(line);
            setDestLineId(line.id);
          }}
          draggable={hasTrain && canCreateManovr}
          onDragStart={(e) => {
            if (hasTrain && canCreateManovr) {
              e.dataTransfer.setData("trainId", String(train.id));
              e.currentTarget.style.opacity = "0.5";
            }
          }}
          onDragEnd={(e) => {
            e.currentTarget.style.opacity = "1";
          }}
          onDragOver={(e) => {
            if (canCreateManovr) {
              e.preventDefault();
              e.currentTarget.style.borderColor = "var(--accent)";
              e.currentTarget.style.backgroundColor = "var(--accent-soft)";
            }
          }}
          onDragLeave={(e) => {
            e.currentTarget.style.borderColor = style ? style.border : "var(--line)";
            e.currentTarget.style.backgroundColor = style ? style.bg : "color-mix(in oklab, var(--bg) 60%, var(--panel))";
          }}
          onDrop={(e) => {
            if (!canCreateManovr) return;
            e.preventDefault();
            const trIdStr = e.dataTransfer.getData("trainId");
            if (!trIdStr) return;
            const trId = Number(trIdStr);
            const trainObj = trains.find((t) => t.id === trId);
            if (!trainObj) return;

            e.currentTarget.style.borderColor = style ? style.border : "var(--line)";
            e.currentTarget.style.backgroundColor = style ? style.bg : "color-mix(in oklab, var(--bg) 60%, var(--panel))";

            if (trainObj.lineId === line.id) return;

            const occupiedSlots = trains.filter(t => t.lineId === line.id && !t.isDisposed).map(t => t.slotIndex);
            if (occupiedSlots.length >= line.capacity) {
              alert("ظرفیت ریل مقصد تکمیل است.");
              return;
            }

            let targetSlotIdx = 0;
            for (let idx = 0; idx < line.capacity; idx++) {
              if (!occupiedSlots.includes(idx)) {
                targetSlotIdx = idx;
                break;
              }
            }

            setSourceLineId(trainObj.lineId);
            setDestLineId(line.id);
            setTargetSlot(targetSlotIdx);
            setPreSelectedTrainId(trainObj.id);
            setShowManovrModal(true);
          }}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "6px 12px",
            border: `1px solid ${style ? style.border : "var(--line)"}`,
            borderRadius: "var(--r-sm)",
            backgroundColor: style ? style.bg : "color-mix(in oklab, var(--bg) 60%, var(--panel))",
            color: style ? style.text : "var(--ink)",
            cursor: "pointer",
            minHeight: "38px",
            transition: "var(--transition-fluid)",
            boxShadow: style ? "var(--sh-1)" : "none",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = "var(--accent)";
            e.currentTarget.style.transform = "scale(1.02)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = style ? style.border : "var(--line)";
            e.currentTarget.style.backgroundColor = style ? style.bg : "color-mix(in oklab, var(--bg) 60%, var(--panel))";
            e.currentTarget.style.transform = "none";
          }}
        >
          <span style={{ fontSize: "11px", fontWeight: "600", color: "var(--ink-soft)" }}>{label}</span>
          {hasTrain ? (
            <div style={{ display: "flex", alignItems: "center", gap: "6px", flexWrap: "wrap", justifyContent: "flex-end", maxWidth: "70%" }}>
              {lineTrains.map((tr) => {
                const trStyle = STATUS_STYLE[tr.status] || STATUS_STYLE[1];
                return (
                  <div
                    key={tr.id}
                    title={`قطار ${tr.code} (${trStyle.label})`}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "4px",
                      fontWeight: "bold",
                      fontSize: "11px",
                      padding: "2px 6px",
                      borderRadius: "4px",
                      backgroundColor: trStyle?.badge,
                      color: "#ffffff",
                    }}
                    className="num"
                  >
                    <trStyle.IconComp size={11} weight="bold" />
                    <span>{tr.code}</span>
                  </div>
                );
              })}
            </div>
          ) : (
            <span style={{ fontSize: "11px", color: "var(--ink-faint)" }}>—</span>
          )}
        </div>
      );
    };

    const getHeaderStyle = (terminalId: number) => {
      const config = ZONE_CONFIG[terminalId];
      const accentColor = config?.color || "var(--accent)";
      return {
        borderRadius: "var(--r-md)",
        overflow: "hidden",
        backgroundColor: "var(--panel)",
        border: "1px solid var(--line)",
        borderTop: `4px solid ${accentColor}`,
        boxShadow: "var(--sh-2)",
        transition: "var(--transition-fluid)",
      };
    };

    const getGradientColorsForTerminal = (terminalId: number) => {
      switch (terminalId) {
        case 1: // دیزل‌شاپ
          return { primary: '#ef4444', secondary: '#f87171', accent: '#fca5a5' };
        case 2: // واگن‌سازی
          return { primary: '#f59e0b', secondary: '#fbbf24', accent: '#fde68a' };
        case 4: // پارکینگ شمالی
          return { primary: '#3b82f6', secondary: '#60a5fa', accent: '#93c5fd' };
        case 5: // پارکینگ جنوبی
          return { primary: '#06b6d4', secondary: '#22d3ee', accent: '#67e8f9' };
        case 6: // خطوط فرعی غرب
          return { primary: '#8b5cf6', secondary: '#a78bfa', accent: '#c4b5fd' };
        case 7: // خطوط فرعی شرق
          return { primary: '#ec4899', secondary: '#f472b6', accent: '#f9a8d4' };
        case 3: // خط اصلی
          return { primary: '#64748b', secondary: '#94a3b8', accent: '#cbd5e1' };
        case 8: // سایر خطوط
          return { primary: '#475569', secondary: '#64748b', accent: '#cbd5e1' };
        default:
          return { primary: '#64748b', secondary: '#94a3b8', accent: '#cbd5e1' };
      }
    };

    const getInnerCardStyle = () => {
      return {
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column" as const,
        overflow: "hidden",
      };
    };

    const getTitleStyle = (terminalId: number) => {
      return {
        backgroundColor: "rgba(0,0,0,0.02)",
        padding: "10px 14px",
        fontWeight: "bold",
        textAlign: "center" as const,
        fontSize: "12.5px",
        borderBottom: "1px solid var(--line)",
        color: "var(--ink)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "6px",
      };
    };

    return (
      <div
        style={{
          flex: 1,
          width: "100%",
          overflow: "auto",
          padding: "20px",
          backgroundColor: appearance.theme === "dark" ? "#070a12" : "#f1f5f9",
          display: "flex",
          flexDirection: "column",
          gap: "20px",
        }}
      >
        {/* راهنمای وضعیت قطارها */}
        <div
          style={{
            display: "flex",
            gap: "16px",
            alignItems: "center",
            padding: "12px 20px",
            backgroundColor: "var(--panel)",
            border: "1px solid var(--line)",
            borderRadius: "var(--r-md)",
            boxShadow: "var(--sh-2)",
            fontSize: "12px",
            fontWeight: "600",
            minWidth: "1100px",
          }}
        >
          <span style={{ color: "var(--ink-soft)" }}>وضعیت ناوگان:</span>
          {Object.entries(STATUS_STYLE).map(([code, style]) => (
            <div key={code} style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <span style={{ color: style.text, display: "inline-flex" }}>
                <style.IconComp size={13} weight="bold" />
              </span>
              <span
                style={{
                  fontWeight: "bold",
                  padding: "2px 8px",
                  borderRadius: "4px",
                  backgroundColor: style.bg,
                  color: style.text,
                  border: `1px solid ${style.border}`,
                }}
              >
                {style.label}
              </span>
            </div>
          ))}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(5, 1fr)",
            gap: "20px",
            minWidth: "1100px",
            direction: "rtl",
          }}
        >
          {[1, 2, 3, 4, 5].map((colIdx) => (
            <div key={colIdx} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              {columnsData[colIdx]?.map((term) => {
                if (term.code === 5) {
                  return (
                    <BorderRotate
                      key={term.code}
                      gradientColors={getGradientColorsForTerminal(5)}
                      backgroundColor="var(--panel)"
                      borderRadius={12}
                      borderWidth={2}
                      animationSpeed={8}
                      style={{ boxShadow: "var(--sh-2)" }}
                    >
                      <div style={getInnerCardStyle()}>
                        <div style={getTitleStyle(5)}>
                          <span>{term.label}</span>
                        </div>
                        <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "10px" }}>
                          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                              {Array.from({ length: 12 }, (_, i) => renderSlot(`پارکینگ جنوبی ${i + 1}`, String(i + 1)))}
                            </div>
                            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                              {Array.from({ length: 12 }, (_, i) => renderSlot(`پارکینگ جنوبی ${i + 13}`, String(i + 13)))}
                            </div>
                          </div>
                          <div>
                            {renderSlot("پارکینگ جنوبی 25", "25")}
                          </div>
                        </div>
                      </div>
                    </BorderRotate>
                  );
                }
                if (term.code === 6) {
                  return (
                    <BorderRotate
                      key={term.code}
                      gradientColors={getGradientColorsForTerminal(6)}
                      backgroundColor="var(--panel)"
                      borderRadius={12}
                      borderWidth={2}
                      animationSpeed={8}
                      style={{ boxShadow: "var(--sh-2)" }}
                    >
                      <div style={getInnerCardStyle()}>
                        <div style={getTitleStyle(6)}>
                          <span>{term.label}</span>
                        </div>
                        <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "6px" }}>
                          {renderSlot("دوار غربی", "دوار غربی")}
                          {renderSlot("دوار شرقی", "دوار شرقی")}
                          {renderSlot("آبگیری", "آبگیری")}
                          {renderSlot("خط کور2", "خط کور ۲")}
                        </div>
                      </div>
                    </BorderRotate>
                  );
                }
                if (term.code === 4) {
                  return (
                    <BorderRotate
                      key={term.code}
                      gradientColors={getGradientColorsForTerminal(4)}
                      backgroundColor="var(--panel)"
                      borderRadius={12}
                      borderWidth={2}
                      animationSpeed={8}
                      style={{ boxShadow: "var(--sh-2)" }}
                    >
                      <div style={getInnerCardStyle()}>
                        <div style={getTitleStyle(4)}>
                          <span>{term.label}</span>
                        </div>
                        <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "10px" }}>
                          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                              {Array.from({ length: 12 }, (_, i) => renderSlot(`پارکینگ شمالی ${i + 1}`, String(i + 1)))}
                            </div>
                            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                              {Array.from({ length: 12 }, (_, i) => renderSlot(`پارکینگ شمالی ${i + 13}`, String(i + 13)))}
                            </div>
                          </div>
                          <div>
                            {renderSlot("پارکینگ شمالی 25", "25")}
                          </div>
                        </div>
                      </div>
                    </BorderRotate>
                  );
                }
                if (term.code === 7) {
                  return (
                    <BorderRotate
                      key={term.code}
                      gradientColors={getGradientColorsForTerminal(7)}
                      backgroundColor="var(--panel)"
                      borderRadius={12}
                      borderWidth={2}
                      animationSpeed={8}
                      style={{ boxShadow: "var(--sh-2)" }}
                    >
                      <div style={getInnerCardStyle()}>
                        <div style={getTitleStyle(7)}>
                          <span>{term.label}</span>
                        </div>
                        <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "6px" }}>
                          {renderSlot("متروواش", "متروواش")}
                          {renderSlot("پیتلاین", "پیتلاین")}
                          {renderSlot("مجاور سوله", "مجاور سوله")}
                          {renderSlot("مجاور مرکز", "مجاور مرکز")}
                        </div>
                      </div>
                    </BorderRotate>
                  );
                }
                if (term.code === 3) {
                  return (
                    <BorderRotate
                      key={term.code}
                      gradientColors={getGradientColorsForTerminal(3)}
                      backgroundColor="var(--panel)"
                      borderRadius={12}
                      borderWidth={2}
                      animationSpeed={8}
                      style={{ boxShadow: "var(--sh-2)", display: "flex", flexDirection: "column", minHeight: "280px" }}
                    >
                      <div style={getInnerCardStyle()}>
                        <div style={getTitleStyle(3)}>
                          <span>{term.label}</span>
                        </div>
                        <div style={{ padding: "14px", flex: 1, overflowY: "auto" }}>
                          {(() => {
                            const mainLineObj = lines.find(l => l.name === "خط اصلی");
                            if (!mainLineObj) return <div style={{ color: "var(--ink-faint)", textAlign: "center", marginTop: "20px" }}>خط اصلی یافت نشد.</div>;
                            const mainLineTrains = trains.filter(t => t.lineId === mainLineObj.id && !t.isDisposed);
                            return (
                              <div
                                onClick={() => setSelectedLine(mainLineObj)}
                                onDragOver={(e) => {
                                  if (canCreateManovr) {
                                    e.preventDefault();
                                    e.currentTarget.style.backgroundColor = "var(--accent-soft)";
                                  }
                                }}
                                onDragLeave={(e) => {
                                  e.currentTarget.style.backgroundColor = "transparent";
                                }}
                                onDrop={(e) => {
                                  if (!canCreateManovr) return;
                                  e.preventDefault();
                                  e.currentTarget.style.backgroundColor = "transparent";
                                  const trIdStr = e.dataTransfer.getData("trainId");
                                  if (!trIdStr) return;
                                  const trId = Number(trIdStr);
                                  const trainObj = trains.find((t) => t.id === trId);
                                  if (!trainObj) return;

                                  if (trainObj.lineId === mainLineObj.id) return;

                                  const occupiedSlots = trains.filter(t => t.lineId === mainLineObj.id && !t.isDisposed).map(t => t.slotIndex);
                                  if (occupiedSlots.length >= mainLineObj.capacity) {
                                    alert("ظرفیت ریل مقصد تکمیل است.");
                                    return;
                                  }

                                  let targetSlotIdx = 0;
                                  for (let idx = 0; idx < mainLineObj.capacity; idx++) {
                                    if (!occupiedSlots.includes(idx)) {
                                      targetSlotIdx = idx;
                                      break;
                                    }
                                  }

                                  setSourceLineId(trainObj.lineId);
                                  setDestLineId(mainLineObj.id);
                                  setTargetSlot(targetSlotIdx);
                                  setPreSelectedTrainId(trainObj.id);
                                  setShowManovrModal(true);
                                }}
                                style={{ cursor: "pointer", height: "100%", transition: "background 0.2s ease-out", borderRadius: "var(--r-sm)" }}
                              >
                                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                                  <thead>
                                    <tr style={{ borderBottom: "2px solid var(--line)" }}>
                                      <th style={{ padding: "8px", textAlign: "center" }}>کد قطار</th>
                                      <th style={{ padding: "8px", textAlign: "center" }}>نوع ناوگان</th>
                                      <th style={{ padding: "8px", textAlign: "center" }}>جایگاه</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {mainLineTrains.map((tr) => (
                                      <tr
                                        key={tr.id}
                                        draggable={canCreateManovr}
                                        onDragStart={(e) => {
                                          if (canCreateManovr) {
                                            e.dataTransfer.setData("trainId", String(tr.id));
                                            e.currentTarget.style.opacity = "0.5";
                                          }
                                        }}
                                        onDragEnd={(e) => {
                                          e.currentTarget.style.opacity = "1";
                                        }}
                                        style={{ borderBottom: "1px solid var(--line-soft)", height: "38px", cursor: "grab" }}
                                      >
                                        <td style={{ padding: "8px", fontWeight: "bold", textAlign: "center" }} className="num">{tr.code}</td>
                                        <td style={{ padding: "8px", textAlign: "center" }}>{tr.type === 0 ? "AC" : "DC"}</td>
                                        <td style={{ padding: "8px", textAlign: "center" }} className="num">{tr.slotIndex + 1}</td>
                                      </tr>
                                    ))}
                                    {mainLineTrains.length === 0 && (
                                      <tr>
                                        <td colSpan={3} style={{ textAlign: "center", padding: "24px", color: "var(--ink-faint)" }}>
                                          هیچ قطاری مستقر نیست
                                        </td>
                                      </tr>
                                    )}
                                  </tbody>
                                </table>
                              </div>
                            );
                          })()}
                        </div>
                      </div>
                    </BorderRotate>
                  );
                }
                if (term.code === 8) {
                  const termLines = lines.filter(l => l.terminal === 8).sort((a, b) => {
                    const ma = a.name.match(/(\d+)/);
                    const mb = b.name.match(/(\d+)/);
                    if (ma && mb) return parseInt(ma[1], 10) - parseInt(mb[1], 10);
                    return a.name.localeCompare(b.name, "fa");
                  });
                  return (
                    <BorderRotate
                      key={term.code}
                      gradientColors={getGradientColorsForTerminal(8)}
                      backgroundColor="var(--panel)"
                      borderRadius={12}
                      borderWidth={2}
                      animationSpeed={8}
                      style={{ boxShadow: "var(--sh-2)" }}
                    >
                      <div style={getInnerCardStyle()}>
                        <div style={getTitleStyle(8)}>
                          <span>{term.label}</span>
                        </div>
                        <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "6px" }}>
                          {termLines.map(l => renderSlot(l.name, l.name))}
                          {termLines.length === 0 && (
                            <div style={{ fontSize: "11px", color: "var(--ink-faint)", textAlign: "center", padding: "12px" }}>
                              هیچ خطی ثبت نشده است
                            </div>
                          )}
                        </div>
                      </div>
                    </BorderRotate>
                  );
                }
                if (term.code === 2) {
                  return (
                    <BorderRotate
                      key={term.code}
                      gradientColors={getGradientColorsForTerminal(2)}
                      backgroundColor="var(--panel)"
                      borderRadius={12}
                      borderWidth={2}
                      animationSpeed={8}
                      style={{ boxShadow: "var(--sh-2)" }}
                    >
                      <div style={getInnerCardStyle()}>
                        <div style={getTitleStyle(2)}>
                          <span>{term.label}</span>
                        </div>
                        <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "6px" }}>
                          {Array.from({ length: 16 }, (_, i) => renderSlot(`واگن سازی ${i + 1}`, String(i + 1)))}
                          <div style={{ margin: "8px 0", borderTop: "1px dashed var(--line)" }} />
                          {renderSlot("بادگیری", "بادگیری")}
                          {renderSlot("خط کور1", "خط کور ۱")}
                        </div>
                      </div>
                    </BorderRotate>
                  );
                }
                if (term.code === 1) {
                  return (
                    <BorderRotate
                      key={term.code}
                      gradientColors={getGradientColorsForTerminal(1)}
                      backgroundColor="var(--panel)"
                      borderRadius={12}
                      borderWidth={2}
                      animationSpeed={8}
                      style={{ boxShadow: "var(--sh-2)" }}
                    >
                      <div style={getInnerCardStyle()}>
                        <div style={getTitleStyle(1)}>
                          <span>{term.label}</span>
                        </div>
                        <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "6px" }}>
                          {renderSlot("خط تست", "خط تست")}
                          {renderSlot("D7G", "D7G")}
                          {renderSlot("باطری خانه", "باطری خانه")}
                          {renderSlot("دیزل شاپ B1", "B1")}
                          {renderSlot("دیزل شاپ B2", "B2")}
                          <div style={{ margin: "4px 0", borderTop: "1px dashed var(--line)" }} />
                          {Array.from({ length: 10 }, (_, i) => renderSlot(`دیزل شاپ ${i + 1}`, String(i + 1)))}
                          <div style={{ margin: "4px 0", borderTop: "1px dashed var(--line)" }} />
                          {renderSlot("کارخانه 1", "کارخانه ۱")}
                          {renderSlot("کارخانه 2", "کارخانه ۲")}
                          {renderSlot("کارخانه 3", "کارخانه ۳")}
                        </div>
                      </div>
                    </BorderRotate>
                  );
                }

                // ترمینال‌های جدید دینامیک
                const termLines = lines.filter((l) => l.terminal === term.code);
                return (
                  <BorderRotate
                    key={term.code}
                    gradientColors={getGradientColorsForTerminal(term.code)}
                    backgroundColor="var(--panel)"
                    borderRadius={12}
                    borderWidth={2}
                    animationSpeed={8}
                    style={{ boxShadow: "var(--sh-2)" }}
                  >
                    <div style={getInnerCardStyle()}>
                      <div style={getTitleStyle(term.code)}>
                        <span>{term.label}</span>
                      </div>
                      <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "6px" }}>
                        {termLines.map((line) => renderSlot(line.name, line.tag || line.name))}
                        {termLines.length === 0 && (
                          <div style={{ fontSize: "11px", color: "var(--ink-faint)", textAlign: "center", padding: "10px" }}>
                            بدون ریل متصل
                          </div>
                        )}
                      </div>
                    </div>
                  </BorderRotate>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div style={{ height: "100%", width: "100%", display: "flex", flexDirection: "column", position: "relative" }}>
      
      {/* هدر بالایی کنترل صحنه دپو */}
      <div
        style={{
          width: "100%",
          padding: "12px 20px",
          backgroundColor: "var(--panel)",
          borderBottom: "1px solid var(--line)",
          display: "flex",
          alignItems: "center",
          gap: "10px",
          zIndex: 10,
          boxShadow: "var(--sh-1)",
        }}
      >
        <button
          className="btn primary"
          onClick={() => setCurrentQuality((prev) => (prev === "2d" ? "high" : "2d"))}
          style={{ fontWeight: "bold", background: "linear-gradient(135deg, var(--accent) 0%, var(--accent-hover) 100%)", color: "#fff" }}
        >
          {currentQuality === "2d" ? "🖥️ نمای سه‌بعدی دپو" : "📋 نمای دوبعدی (نقشه)"}
        </button>

        {cameraFocusTarget && currentQuality !== "2d" && (
          <button
            className="btn accent"
            onClick={() => setCameraFocusTarget(null)}
            style={{ fontWeight: "bold" }}
          >
            🏠 نمای کلی پایانه
          </button>
        )}

        <button className="btn" onClick={() => setShowSearch(true)} title="جستجوی سریع (Ctrl+K)">
          🔍 جستجوی سریع
        </button>

        {Object.keys(modifiedPositions).length > 0 && currentQuality !== "2d" && (
          <button className="btn primary" onClick={handleSaveLayout} disabled={isSavingLayout}>
            {isSavingLayout ? "در حال ثبت چیدمان..." : "ذخیره نهایی چیدمان ریل‌ها"}
          </button>
        )}
      </div>

      {/* بدنه اصلی صحنه: سه‌بعدی یا دوبعدی */}
      {currentQuality === "2d" ? (
        render2DMap()
      ) : (
        <Canvas
          shadows
          frameloop="demand"
          camera={{ position: [0, 380, 420], fov: 42, near: 1, far: 2500 }}
          gl={{ antialias: true, powerPreference: "high-performance" }}
          style={{
            flex: 1,
            background: appearance.theme === "dark"
              ? "linear-gradient(180deg, #0a0e14 0%, #131a26 100%)"
              : "linear-gradient(180deg, #f5f7fa 0%, #dfe6ee 100%)",
          }}
        >
          {/* نورپردازی صحنه — لطیف در هر دو تم */}
          <ambientLight intensity={appearance.theme === "dark" ? 0.35 : 0.55} />
          <hemisphereLight
            args={[
              appearance.theme === "dark" ? "#7ea6d8" : "#eef4ff",
              appearance.theme === "dark" ? "#101828" : "#c7d2df",
              appearance.theme === "dark" ? 0.35 : 0.6,
            ]}
          />
          <directionalLight
            position={[120, 200, 80]}
            intensity={appearance.theme === "dark" ? 1.0 : 1.4}
            castShadow
            shadow-mapSize={[2048, 2048]}
            shadow-camera-left={-400}
            shadow-camera-right={400}
            shadow-camera-top={300}
            shadow-camera-bottom={-300}
            shadow-bias={-0.0005}
          />
          {currentQuality === "high" && (
            <Environment preset={appearance.theme === "dark" ? "night" : "city"} />
          )}

          {/* کف پایانه — گرید ظریف صنعتی */}
          <Grid
            args={[1400, 700]}
            position={[0, 0, 0]}
            cellSize={6}
            cellThickness={0.6}
            cellColor={appearance.theme === "dark" ? "#1e2a3b" : "#c3ccd8"}
            sectionSize={60}
            sectionThickness={1.2}
            sectionColor={appearance.theme === "dark" ? "#2a3a52" : "#94a3b8"}
            fadeDistance={520}
            fadeStrength={1}
            infiniteGrid={false}
            followCamera={false}
          />

          {/* کامپوننت هدایت زنده دوربین */}
          <CameraDirector focusTarget={cameraFocusTarget} controlsRef={controlsRef} />

          {/* رندر مناطق و سوله‌های پایانه دپو — عرض هر سوله بر اساس تعداد خطوطش پویا است */}
          {Object.entries(ZONES).map(([id, zone]) => {
            const termId = Number(id);
            const isFull = (zone as any).gridRow === "full";
            const lineCount = lines.filter((l) => l.terminal === termId).length;

            // مطابق seed-v3.mjs: SHED_PAD=12, RAIL_STEP=8, MIN=90, MAX=220
            const shedW = Math.min(220, Math.max(90, 24 + Math.max(0, lineCount - 1) * 8));
            const shedD = isFull ? 180 : 90;

            // کف زون کمی کوچک‌تر از سوله باشد تا بیرون از دیوار نشت نکند
            const gW = shedW - 4;
            const gD = shedD - 4;
            return (
              <group key={id}>
                {/* کف زون — رنگ لهجه با اشباع پایین برای شناسایی سریع */}
                <mesh
                  rotation={[-Math.PI / 2, 0, 0]}
                  position={[zone.x, 0.05, zone.z]}
                  receiveShadow
                  raycast={() => null}
                >
                  <planeGeometry args={[gW, gD]} />
                  <meshStandardMaterial
                    color={zone.color}
                    roughness={0.95}
                    metalness={0.02}
                    transparent
                    opacity={appearance.theme === "dark" ? 0.22 : 0.28}
                  />
                </mesh>

                {/* سایه‌ی نرم زیر سوله برای عمق تصویری */}
                {currentQuality === "high" && (
                  <ContactShadows
                    position={[zone.x, 0.06, zone.z]}
                    opacity={appearance.theme === "dark" ? 0.55 : 0.35}
                    scale={Math.max(gW, gD) * 1.1}
                    blur={2.4}
                    far={20}
                    resolution={512}
                    color="#000000"
                  />
                )}

                {/* سازه سه‌بعدی سوله */}
                <IndustrialShed
                  zoneX={zone.x}
                  zoneZ={zone.z}
                  label={zone.label}
                  color={zone.color}
                  gridRow={(zone as any).gridRow ?? "full"}
                  width={shedW}
                  depth={shedD}
                  onSelect={() => setCameraFocusTarget([zone.x, 0, zone.z])}
                />
              </group>
            );
          })}

          {/* رندر ریل‌ها و خطوط آهن */}
          {lines.map((line) => {
            const isModified = !!modifiedPositions[line.id];
            const posX = isModified ? modifiedPositions[line.id].posX : line.posX;
            const posY = isModified ? modifiedPositions[line.id].posY : line.posY;
            const rotation = isModified ? modifiedPositions[line.id].rotation : line.rotation;

            const angle = (rotation * Math.PI) / 180;

            return (
              <group
                key={line.id}
                position={[posX, 0.2, posY]}
                rotation={[0, angle, 0]}
                onPointerOver={(e) => {
                  e.stopPropagation();
                  setHoveredLineId(line.id);
                }}
                onPointerOut={() => {
                  setHoveredLineId(null);
                }}
              >
                {/* ریل فلزی PBR */}
                <mesh castShadow receiveShadow position={[0.9, 0.3, 0]}>
                  <boxGeometry args={[0.35, 0.35, line.length]} />
                  <meshStandardMaterial color="#8fa2b8" metalness={0.9} roughness={0.25} />
                </mesh>
                <mesh castShadow receiveShadow position={[-0.9, 0.3, 0]}>
                  <boxGeometry args={[0.35, 0.35, line.length]} />
                  <meshStandardMaterial color="#8fa2b8" metalness={0.9} roughness={0.25} />
                </mesh>
                {/* بستر تراورس با ته‌رنگ زون (از ZONE_CONFIG) */}
                <mesh receiveShadow>
                  <boxGeometry args={[3, 0.1, line.length]} />
                  <meshStandardMaterial
                    color={ZONES[line.terminal]?.color ?? "#78350f"}
                    roughness={0.95}
                    metalness={0.02}
                  />
                </mesh>

                {/* برچسب نام ریل — فقط هاور/انتخاب. مانور فعال → نشان کوچک (نه لیبل کامل) */}
                {(hoveredLineId === line.id || selectedLine?.id === line.id) && (
                  <Html position={[0, 1.6, -line.length / 2]} center distanceFactor={40} zIndexRange={[100, 0]}>
                    <div
                      style={{
                        background: "color-mix(in oklab, var(--panel) 92%, transparent)",
                        backdropFilter: "blur(6px)",
                        WebkitBackdropFilter: "blur(6px)",
                        color: "var(--ink)",
                        padding: "3px 9px",
                        borderRadius: "999px",
                        fontSize: "11px",
                        fontWeight: 700,
                        whiteSpace: "nowrap",
                        cursor: "pointer",
                        boxShadow: "var(--sh-2)",
                        border: `1px solid ${selectedLine?.id === line.id ? "var(--accent)" : "var(--line)"}`,
                      }}
                      onClick={() => setSelectedLine(line)}
                    >
                      {line.name}
                    </div>
                  </Html>
                )}

                {/* نشان مانور فعال — نقطه‌ی سبز نبضی روی ریل، بدون لیبل متنی */}
                {activeManovrs.some((m) => m.destinationLineId === line.id) &&
                  hoveredLineId !== line.id && selectedLine?.id !== line.id && (
                  <mesh position={[0, 1.4, 0]} raycast={() => null}>
                    <sphereGeometry args={[0.55, 12, 12]} />
                    <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={2.5} />
                  </mesh>
                )}
              </group>
            );
          })}

          {/* رندر قطارها */}
          {trains.map((train) => {
            const line = lines.find((l) => l.id === train.lineId);
            return (
              <TrainModel3D
                key={train.id}
                train={train}
                line={line}
                isDragging={draggedTrainId === train.id}
                dragPos={dragPos}
                onPointerDown={(e) => {
                  if (canCreateManovr) handleTrainDragStart(train.id, [e.point.x, 1.8, e.point.z]);
                }}
                onClick={() => setSelectedTrain(train)}
              />
            );
          })}

          {/* رندر نشانگرهای اسلات خالی جهت بهبود تغییر موقعیت قطار منتخب */}
          {selectedTrain && lines.map((line) => {
            // پیدا کردن اسلات‌های پر شده
            const occupiedSlots = trains.filter((t) => t.lineId === line.id).map((t) => t.slotIndex);
            const emptySlots: number[] = [];
            for (let i = 0; i < line.capacity; i++) {
              if (!occupiedSlots.includes(i)) {
                emptySlots.push(i);
              }
            }

            const angle = (line.rotation * Math.PI) / 180;
            const slotSpacing = line.length / Math.max(1, line.capacity);

            return emptySlots.map((slotIdx) => {
              const offset = -line.length / 2 + slotIdx * slotSpacing + slotSpacing / 2;
              const dx = Math.sin(angle) * offset;
              const dz = Math.cos(angle) * offset;
              const slotPos = [line.posX + dx, 0.6, line.posY + dz] as [number, number, number];

              return (
                <mesh
                  key={`${line.id}-${slotIdx}`}
                  position={slotPos}
                  rotation={[0, angle, 0]}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSourceLineId(selectedTrain.lineId);
                    setDestLineId(line.id);
                    setTargetSlot(slotIdx);
                    setShowManovrModal(true);
                    setSelectedTrain(null);
                  }}
                  onPointerOver={() => { document.body.style.cursor = "pointer"; }}
                  onPointerOut={() => { document.body.style.cursor = "auto"; }}
                >
                  <cylinderGeometry args={[1.6, 1.6, 0.4, 16]} />
                  <meshStandardMaterial
                    color="#22c55e"
                    emissive="#22c55e"
                    emissiveIntensity={1.2}
                    transparent
                    opacity={0.75}
                  />
                </mesh>
              );
            });
          })}

          <CameraController defaultTerminal={prefs.defaultTerminal} lines={lines} zones={ZONES} />
          <OrbitControls
            ref={controlsRef}
            makeDefault
            maxPolarAngle={Math.PI / 2.15}
            minDistance={20}
            maxDistance={800}
            target={[0, 0, 0]}
            enableDamping
            dampingFactor={0.08}
          />
        </Canvas>
      )}

      {/* مودال اطلاعات قطار منتخب */}
      {selectedTrain && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            backgroundColor: "rgba(15,23,42,0.4)",
            backdropFilter: "blur(6px)",
            zIndex: 100000,
            display: "grid",
            placeItems: "center",
          }}
        >
          <div className="card" style={{ width: "450px", backgroundColor: "var(--panel)" }}>
            <div className="card-head">
              <h2>قطار شماره {selectedTrain.code}</h2>
              <span className="spacer" />
              <button className="btn sm" onClick={() => setSelectedTrain(null)}>
                بستن
              </button>
            </div>
            <div className="card-body" style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span className="muted">نوع قطار:</span>
                <b>{TrainType[selectedTrain.type]}</b>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span className="muted">خط استقرار جاری:</span>
                <b>
                  {lines.find((l) => l.id === selectedTrain.lineId)?.name ?? "خارج از ریل / نامشخص"}
                </b>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span className="muted">جایگاه پارک (Slot):</span>
                <b className="num">{selectedTrain.slotIndex + 1}</b>
              </div>

              {canCreateManovr && selectedTrain.lineId && (
                <button
                  className="btn primary"
                  style={{ marginTop: "12px", width: "100%" }}
                  onClick={() => {
                    setSourceLineId(selectedTrain.lineId);
                    setSelectedTrain(null);
                    alert("ریل مقصد را در صحنه کلیک کنید یا با درگ قطار را جابجا کنید.");
                  }}
                >
                  شروع فرآیند مانور برای این قطار
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* مودال جامع کنترل و مدیریت ریل انتخابی */}
      {selectedLine && (() => {
        const lineTrains = trains.filter((t) => t.lineId === selectedLine.id);
        const isFull = lineTrains.length >= selectedLine.capacity;

        // محاسبه اسلات‌های خالی ریل مقصد انتخابی مانور
        const destLineObj = lines.find((l) => l.id === Number(manovrDestLineId));
        const emptyDestSlots: number[] = [];
        if (destLineObj) {
          const occupied = trains.filter((t) => t.lineId === destLineObj.id).map((t) => t.slotIndex);
          for (let i = 0; i < destLineObj.capacity; i++) {
            if (!occupied.includes(i)) emptyDestSlots.push(i);
          }
        }

        // محاسبه اسلات‌های خالی ریل مقصد انتخابی جابجایی سریع
        const relocateLineObj = lines.find((l) => l.id === Number(relocateLineId));
        const emptyRelocateSlots: number[] = [];
        if (relocateLineObj) {
          const occupied = trains.filter((t) => t.lineId === relocateLineObj.id).map((t) => t.slotIndex);
          for (let i = 0; i < relocateLineObj.capacity; i++) {
            if (!occupied.includes(i)) emptyRelocateSlots.push(i);
          }
        }

        // سابمیت ثبت مانور
        const handleTab2Submit = async (e: React.FormEvent) => {
          e.preventDefault();
          if (!manovrTrainId || !manovrDestLineId || !manovrRahbar1) {
            alert("لطفاً قطار، خط مقصد و راهبر مسئول را انتخاب کنید.");
            return;
          }
          const fd = new FormData();
          fd.append("trainId", String(manovrTrainId));
          fd.append("sourceLineId", String(selectedLine.id));
          fd.append("destinationLineId", String(manovrDestLineId));
          fd.append("slotIndex", String(manovrSlotIdx));
          fd.append("rahbar1Id", String(manovrRahbar1));
          if (manovrRahbar2) fd.append("rahbar2Id", String(manovrRahbar2));
          fd.append("type", String(manovrType));
          fd.append("description", manovrDesc);
          fd.append("executionTime", manovrExecutionTime);

          startTransition(async () => {
            const res = await createManovr(null, fd);
            if (res?.error) {
              alert(res.error);
            } else {
              setSelectedLine(null);
              router.refresh();
            }
          });
        };

        // سابمیت جابجایی سریع
        const handleRelocateSubmit = async (e: React.FormEvent) => {
          e.preventDefault();
          if (!relocateTrainId || !relocateLineId) {
            alert("لطفاً قطار و خط مقصد را انتخاب کنید.");
            return;
          }
          startTransition(async () => {
            const res = await relocateTrainDirectly(Number(relocateTrainId), Number(relocateLineId), relocateSlotIdx);
            if (res.error) {
              alert(res.error);
            } else {
              setSelectedLine(null);
              router.refresh();
            }
          });
        };

        return (
          <div
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              width: "100vw",
              height: "100vh",
              backgroundColor: "rgba(15,23,42,0.4)",
              backdropFilter: "blur(6px)",
              zIndex: 100000,
              display: "grid",
              placeItems: "center",
            }}
          >
            <div className="card" style={{ width: "500px", backgroundColor: "var(--panel)", overflow: "visible" }}>
              <div className="card-head" style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px" }}>
                <div>
                  <h2 style={{ margin: 0 }}>کنترل ریل: {selectedLine.name}</h2>
                  <div style={{ fontSize: "11px", color: "var(--ink-faint)", marginTop: "2px" }}>
                    ترمینال: {TerminalEnum[selectedLine.terminal]} | ظرفیت: {lineTrains.length} / {selectedLine.capacity}
                  </div>
                </div>
                <span className="spacer" />
                {canManageLines && (
                  <button
                    className={`btn sm ${((selectedLine as any).isActive !== false) ? "danger" : "primary"}`}
                    onClick={async () => {
                      const currentActive = (selectedLine as any).isActive !== false;
                      const res = await toggleLineActive(selectedLine.id, !currentActive);
                      if (res.error) {
                        alert(res.error);
                      } else {
                        (selectedLine as any).isActive = !currentActive;
                        setSelectedLine({ ...selectedLine });
                        const found = lines.find(l => l.id === selectedLine.id);
                        if (found) (found as any).isActive = !currentActive;
                        router.refresh();
                      }
                    }}
                    style={{ fontWeight: "bold" }}
                  >
                    {((selectedLine as any).isActive !== false) ? "🔴 مسدود کردن خط" : "🟢 فعال‌سازی خط"}
                  </button>
                )}
                <button className="btn sm" onClick={() => setSelectedLine(null)}>
                  بستن
                </button>
              </div>

              {/* هدر تب‌ها */}
              <div style={{ display: "flex", borderBottom: "1px solid var(--line)", backgroundColor: "var(--panel-2)" }}>
                <button
                  type="button"
                  style={{
                    flex: 1,
                    padding: "10px 0",
                    border: 0,
                    backgroundColor: "transparent",
                    color: activeLineTab === "details" ? "var(--accent)" : "var(--ink-soft)",
                    borderBottom: activeLineTab === "details" ? "2px solid var(--accent)" : "none",
                    fontWeight: "bold",
                    cursor: "pointer",
                    fontSize: "12.5px",
                  }}
                  onClick={() => setActiveLineTab("details")}
                >
                  قطارهای مستقر
                </button>
                <button
                  type="button"
                  style={{
                    flex: 1,
                    padding: "10px 0",
                    border: 0,
                    backgroundColor: "transparent",
                    color: activeLineTab === "manovr" ? "var(--accent)" : "var(--ink-soft)",
                    borderBottom: activeLineTab === "manovr" ? "2px solid var(--accent)" : "none",
                    fontWeight: "bold",
                    cursor: "pointer",
                    fontSize: "12.5px",
                  }}
                  onClick={() => {
                    setActiveLineTab("manovr");
                    // مقداردهی اولیه برای خروج اولین قطار در صورت وجود
                    if (lineTrains.length > 0 && !manovrTrainId) {
                      setManovrTrainId(lineTrains[0].id);
                    }
                  }}
                >
                  ثبت مانور جابجایی
                </button>
                {canLayout && (
                  <button
                    type="button"
                    style={{
                      flex: 1,
                      padding: "10px 0",
                      border: 0,
                      backgroundColor: "transparent",
                      color: activeLineTab === "relocate" ? "var(--accent)" : "var(--ink-soft)",
                      borderBottom: activeLineTab === "relocate" ? "2px solid var(--accent)" : "none",
                      fontWeight: "bold",
                      cursor: "pointer",
                      fontSize: "12.5px",
                    }}
                    onClick={() => {
                      setActiveLineTab("relocate");
                    }}
                  >
                    انتقال سریع (ادمین)
                  </button>
                )}
              </div>

              <div className="card-body" style={{ padding: "16px", overflow: "visible" }}>
                
                {/* تب ۱: قطارهای مستقر */}
                {activeLineTab === "details" && (
                  <div style={{ display: "flex", flexDirection: "column", gap: "12px", overflow: "visible" }}>
                    <h3 style={{ fontSize: "13px", fontWeight: "bold", margin: "0 0 4px 0" }}>فهرست ناوگان پارک شده:</h3>
                    
                    <div style={{ display: "flex", flexDirection: "column", gap: "8px", maxHeight: "160px", overflowY: "auto", padding: "2px" }}>
                      {lineTrains.length === 0 ? (
                        <div className="muted" style={{ padding: "16px", textAlign: "center", backgroundColor: "var(--panel-2)", borderRadius: "6px", fontSize: "12.5px" }}>
                          در حال حاضر هیچ قطاری در این ریل مستقر نیست.
                        </div>
                      ) : (
                        lineTrains.map((tr) => (
                          <div
                            key={tr.id}
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "center",
                              padding: "8px 12px",
                              backgroundColor: "var(--panel-2)",
                              borderRadius: "8px",
                              border: "1px solid var(--line)",
                            }}
                          >
                            <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                              <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                                <span style={{ fontWeight: "bold", fontSize: "13.5px" }} className="num">قطار {tr.code}</span>
                                <span className="pill p-mut num" style={{ fontSize: "10px" }}>
                                  جایگاه {tr.slotIndex + 1}
                                </span>
                              </div>
                              <div style={{ fontSize: "11px", color: "var(--ink-soft)" }}>
                                {tr.status === 2 ? "در اختیار تعمیرات" :
                                 tr.status === 3 ? "غیرفعال / خارج سرویس" :
                                 tr.status === 4 ? "در حال اعزام" : "آماده به کار / استندبای"}
                              </div>
                            </div>

                            <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
                              {canManageLines && (
                                <select
                                  value={tr.status}
                                  className="input sm"
                                  style={{ padding: "4px 8px", fontSize: "11.5px", width: "120px", height: "30px" }}
                                  onChange={async (e) => {
                                    const newStatus = Number(e.target.value);
                                    startTransition(async () => {
                                      const res = await updateTrainStatus(tr.id, newStatus);
                                      if (res.error) {
                                        alert(res.error);
                                      } else {
                                        router.refresh();
                                      }
                                    });
                                  }}
                                >
                                  <option value="1">آماده / استندبای</option>
                                  <option value="2">تعمیرات</option>
                                  <option value="3">غیرفعال</option>
                                  <option value="4">در حال اعزام</option>
                                </select>
                              )}

                              {canCreateManovr && (
                                <button
                                  type="button"
                                  className="btn sm primary"
                                  style={{ padding: "5px 10px", fontSize: "11.5px", height: "30px" }}
                                  onClick={() => {
                                    setManovrTrainId(tr.id);
                                    setManovrSourceLineId(selectedLine.id);
                                    setActiveLineTab("manovr");
                                  }}
                                >
                                  خروج مانور
                                </button>
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    {/* بخش پارک مستقیم قطار جدید در صورت وجود ظرفیت خالی روی ریل */}
                    {!isFull && canLayout && (
                      <div style={{ marginTop: "14px", padding: "12px", border: "1px dashed var(--line)", borderRadius: "8px", backgroundColor: "var(--panel-2)" }}>
                        <h4 style={{ margin: "0 0 8px 0", fontSize: "12px", fontWeight: "bold", color: "var(--accent)" }}>استقرار قطار جدید روی این ریل:</h4>
                        <form
                          onSubmit={async (e) => {
                            e.preventDefault();
                            const fd = new FormData(e.currentTarget);
                            const trId = Number(fd.get("newTrainId"));
                            const slot = Number(fd.get("newSlotIdx"));
                            if (!trId) return alert("لطفاً قطار را انتخاب کنید.");
                            
                            startTransition(async () => {
                              const res = await relocateTrainDirectly(trId, selectedLine.id, slot);
                              if (res.error) {
                                alert(res.error);
                              } else {
                                setSelectedLine(null);
                                router.refresh();
                              }
                            });
                          }}
                          style={{ display: "flex", flexDirection: "column", gap: "8px" }}
                        >
                          <div className="grid2" style={{ gap: "8px" }}>
                            <div className="field" style={{ marginBottom: 0 }}>
                              <SearchableSelect
                                name="newTrainId"
                                value={newTrainIdState}
                                onChange={setNewTrainIdState}
                                placeholder="-- انتخاب قطار دپو --"
                                required
                                options={trains.filter(t => t.lineId === null).map(t => ({ value: t.id, label: `قطار ${t.code}` }))}
                              />
                            </div>
                            <div className="field" style={{ marginBottom: 0 }}>
                              <select name="newSlotIdx" className="input sm" style={{ padding: "6px 8px", fontSize: "12px" }} required>
                                {(() => {
                                  const occupied = lineTrains.map(t => t.slotIndex);
                                  const empty: number[] = [];
                                  for (let i = 0; i < selectedLine.capacity; i++) {
                                    if (!occupied.includes(i)) empty.push(i);
                                  }
                                  return empty.map(slot => (
                                    <option key={slot} value={slot}>جایگاه {slot + 1}</option>
                                  ));
                                })()}
                              </select>
                            </div>
                          </div>
                          <button type="submit" className="btn sm accent" style={{ width: "100%", justifyContent: "center", padding: "6px 12px" }} disabled={isPending}>
                            {isPending ? "در حال ثبت..." : "ثبت استقرار مستقیم ناوگان"}
                          </button>
                        </form>
                      </div>
                    )}

                  </div>
                )}

                {/* تب ۲: ثبت مانور جابجایی */}
                {activeLineTab === "manovr" && (
                  <form onSubmit={handleTab2Submit} style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    <div className="field">
                      <label>قطار انتخابی جهت جابجایی *</label>
                      <SearchableSelect
                        value={manovrTrainId}
                        onChange={(val) => setManovrTrainId(val ? Number(val) : "")}
                        placeholder="-- انتخاب قطار از روی این خط --"
                        required
                        options={lineTrains.map((t) => ({
                          value: t.id,
                          label: `قطار ${t.code} (مستقر در اسلات {t.slotIndex + 1})`,
                        }))}
                      />
                    </div>

                    <div className="grid2">
                      <div className="field">
                        <label>خط ریل مقصد *</label>
                        <SearchableSelect
                          value={manovrDestLineId}
                          onChange={(val) => {
                            setManovrDestLineId(val ? Number(val) : "");
                            setManovrSlotIdx(0);
                          }}
                          placeholder="-- انتخاب خط مقصد --"
                          required
                          options={lines
                            .filter((l) => l.id !== selectedLine.id)
                            .map((l) => {
                              const capacityLeft = l.capacity - trains.filter((t) => t.lineId === l.id).length;
                              return {
                                value: l.id,
                                label: `${l.name} (ظرفیت خالی: ${capacityLeft} قطار)`,
                                disabled: capacityLeft <= 0,
                              };
                            })}
                        />
                      </div>

                      <div className="field">
                        <label>اسلات پارک مقصد *</label>
                        <select
                          className="input"
                          value={manovrSlotIdx}
                          onChange={(e) => setManovrSlotIdx(Number(e.target.value))}
                          required
                        >
                          {emptyDestSlots.length === 0 ? (
                            <option value="">-- ابتدا خط مقصد را انتخاب کنید --</option>
                          ) : (
                            emptyDestSlots.map((slot) => (
                              <option key={slot} value={slot}>
                                جایگاه {slot + 1}
                              </option>
                            ))
                          )}
                        </select>
                      </div>
                    </div>

                    <div className="field">
                      <label htmlFor="type">نوع مانور عملیاتی *</label>
                      <SearchableSelect
                        value={manovrType}
                        onChange={(val) => setManovrType(val ? Number(val) : 1)}
                        placeholder="-- انتخاب نوع مانور --"
                        required
                        options={Object.entries(ManovrType).map(([val, name]) => ({
                          value: Number(val),
                          label: name as string,
                        }))}
                      />
                    </div>

                    <div className="grid2">
                      <div className="field">
                        <label>راهبر مسئول ۱ *</label>
                        <SearchableSelect
                          value={manovrRahbar1}
                          onChange={(val) => setManovrRahbar1(val ? Number(val) : "")}
                          placeholder="-- انتخاب راهبر --"
                          required
                          options={rahbaran.map((r) => ({
                            value: r.id,
                            label: r.name,
                          }))}
                        />
                      </div>
                      <div className="field">
                        <label>راهبر مسئول ۲</label>
                        <SearchableSelect
                          value={manovrRahbar2}
                          onChange={(val) => setManovrRahbar2(val ? Number(val) : "")}
                          placeholder="-- بدون راهبر دوم --"
                          options={rahbaran.map((r) => ({
                            value: r.id,
                            label: r.name,
                          }))}
                        />
                      </div>
                    </div>

                    <div className="field">
                      <label htmlFor="manovrExecutionTime">زمان اجرای مانور *</label>
                      <JalaliDateTimePicker
                        value={manovrExecutionTime}
                        onChange={(val) => setManovrExecutionTime(val)}
                        required
                      />
                    </div>

                    <div className="field">
                      <label>توضیحات مانور</label>
                      <textarea
                        className="input"
                        rows={2}
                        value={manovrDesc}
                        onChange={(e) => setManovrDesc(e.target.value)}
                      />
                    </div>

                    <button type="submit" className="btn primary" style={{ width: "100%", marginTop: "8px" }} disabled={isPending}>
                      {isPending ? "در حال ثبت مانور..." : "ثبت و اعمال نهایی مانور"}
                    </button>
                  </form>
                )}

                {/* تب ۳: انتقال سریع ادمین */}
                {activeLineTab === "relocate" && canLayout && (
                  <form onSubmit={handleRelocateSubmit} style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    <div className="field">
                      <label>انتخاب قطار دپو *</label>
                      <SearchableSelect
                        value={relocateTrainId}
                        onChange={(val) => setRelocateTrainId(val ? Number(val) : "")}
                        placeholder="-- انتخاب قطار --"
                        required
                        options={trains.map((t) => {
                          const curLine = lines.find((l) => l.id === t.lineId);
                          return {
                            value: t.id,
                            label: `قطار ${t.code} (مستقر در ریل: {curLine?.name ?? "خارج ریل"})`,
                          };
                        })}
                      />
                    </div>

                    <div className="grid2">
                      <div className="field">
                        <label>خط ریل هدف *</label>
                        <SearchableSelect
                          value={relocateLineId}
                          onChange={(val) => {
                            setRelocateLineId(val ? Number(val) : "");
                            setRelocateSlotIdx(0);
                          }}
                          placeholder="-- انتخاب خط مقصد --"
                          required
                          options={lines.map((l) => ({
                            value: l.id,
                            label: `${l.name} (ظرفیت: ${l.capacity})`,
                          }))}
                        />
                      </div>

                      <div className="field">
                        <label>اسلات پارک هدف *</label>
                        <select
                          className="input"
                          value={relocateSlotIdx}
                          onChange={(e) => setRelocateSlotIdx(Number(e.target.value))}
                          required
                        >
                          {emptyRelocateSlots.map((slot) => (
                            <option key={slot} value={slot}>
                              جایگاه {slot + 1}
                            </option>
                          ))}
                          {emptyRelocateSlots.length === 0 && (
                            <option value="">-- بدون اسلات خالی --</option>
                          )}
                        </select>
                      </div>
                    </div>

                    <div style={{ background: "var(--warn-bg)", color: "var(--warn)", padding: "10px", borderRadius: "6px", fontSize: "11px", lineHeight: "1.6" }}>
                      ⚠️ توجه: این جابجایی به صورت مستقیم و بدون ثبت سند رسمی مانور در دیتابیس پایانه انجام می‌شود. صرفاً جهت اصلاحات سریع ادمین!
                    </div>

                    <button type="submit" className="btn primary" style={{ width: "100%", marginTop: "8px" }} disabled={isPending}>
                      {isPending ? "در حال انتقال..." : "انتقال سریع و مستقیم"}
                    </button>
                  </form>
                )}

              </div>
            </div>
          </div>
        );
      })()}

      {/* مودال شناور ثبت مانور سریع */}
      {showManovrModal && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            backgroundColor: "rgba(15,23,42,0.4)",
            backdropFilter: "blur(6px)",
            zIndex: 100000,
            display: "grid",
            placeItems: "center",
          }}
        >
          <div className="card" style={{ width: "500px", backgroundColor: "var(--panel)" }}>
            <div className="card-head">
              <h2>ثبت مانور جابجایی قطار</h2>
              <span className="spacer" />
              <button className="btn sm" onClick={() => setShowManovrModal(false)}>
                بستن
              </button>
            </div>
            <form onSubmit={handleCreateManovrSubmit}>
              <div className="card-body" style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                <div className="grid2">
                  <div className="field">
                    <label>مبدأ مانور</label>
                    <input
                      type="text"
                      className="input"
                      disabled
                      value={lines.find((l) => l.id === sourceLineId)?.name ?? "نامشخص"}
                    />
                  </div>
                  <div className="field">
                    <label>مقصد مانور</label>
                    <input
                      type="text"
                      className="input"
                      disabled
                      value={lines.find((l) => l.id === destLineId)?.name ?? "نامشخص"}
                    />
                  </div>
                </div>

                <div className="field">
                  <label htmlFor="trainId">قطار انتخابی جهت مانور</label>
                  <select
                    id="trainId"
                    name="trainId"
                    className="input"
                    value={preSelectedTrainId || undefined}
                    onChange={(e) => setPreSelectedTrainId(Number(e.target.value))}
                    required
                  >
                    {trains
                      .filter((t) => t.lineId === sourceLineId)
                      .map((t) => (
                        <option key={t.id} value={t.id}>
                          قطار {t.code} ({TrainType[t.type]})
                        </option>
                      ))}
                  </select>
                </div>

                <div className="field">
                  <label htmlFor="type">نوع مانور</label>
                  <select id="type" name="type" className="input" defaultValue="2" required>
                    {Object.entries(ManovrType).map(([val, name]) => (
                      <option key={val} value={val}>
                        {name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid2">
                  <div className="field">
                    <label htmlFor="rahbar1Id">راهبر مسئول ۱ *</label>
                    <select id="rahbar1Id" name="rahbar1Id" className="input" required>
                      <option value="">-- انتخاب کنید --</option>
                      {rahbaran.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="field">
                    <label htmlFor="rahbar2Id">راهبر مسئول ۲ (اختیاری)</label>
                    <select id="rahbar2Id" name="rahbar2Id" className="input">
                      <option value="">-- انتخاب کنید --</option>
                      {rahbaran.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="field">
                  <label htmlFor="executionTime">زمان اجرای مانور *</label>
                  <JalaliDateTimePicker
                    name="executionTime"
                    defaultValue={new Date().toISOString()}
                    required
                  />
                </div>

                <div className="field">
                  <label htmlFor="description">توضیحات تکمیلی</label>
                  <textarea id="description" name="description" className="input" rows={2} />
                </div>

                <div style={{ display: "flex", gap: "10px", marginTop: "12px" }}>
                  <button type="submit" className="btn primary" style={{ flex: 1 }}>
                    ثبت نهایی مانور و انتقال قطار
                  </button>
                  <button
                    type="button"
                    className="btn"
                    style={{ flex: 1 }}
                    onClick={() => setShowManovrModal(false)}
                  >
                    انصراف
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* پنل شناور جستجوی سریع (Ctrl+K) */}
      {showSearch && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            backgroundColor: "rgba(15,23,42,0.4)",
            backdropFilter: "blur(6px)",
            zIndex: 100000,
            display: "grid",
            placeItems: "start center",
            paddingTop: "120px",
          }}
          onClick={() => setShowSearch(false)}
        >
          <div
            className="card"
            style={{ width: "500px", backgroundColor: "var(--panel)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ padding: "16px" }}>
              <input
                type="text"
                className="input"
                placeholder="شماره قطار یا نام ریل را جستجو کنید..."
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />

              <div style={{ marginTop: "12px", maxHeight: "250px", overflowY: "auto", display: "flex", flexDirection: "column", gap: "6px" }}>
                {filteredSearchList.map((item, idx) => (
                  <div
                    key={idx}
                    style={{
                      padding: "8px 12px",
                      backgroundColor: "var(--panel-2)",
                      borderRadius: "6px",
                      cursor: "pointer",
                      fontSize: "13px",
                      fontWeight: "bold",
                    }}
                    onClick={() => handleSearchResultClick(item)}
                  >
                    {item.title}
                  </div>
                ))}

                {searchQuery && filteredSearchList.length === 0 && (
                  <span className="muted" style={{ fontSize: "12px", padding: "4px" }}>
                    موردی یافت نشد.
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
