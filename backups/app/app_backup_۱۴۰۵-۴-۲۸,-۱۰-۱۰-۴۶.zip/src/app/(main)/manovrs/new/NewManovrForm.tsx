"use client";

import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { createManovr } from "@/app/actions/manovr";
import { ManovrType } from "@/lib/enums";
import JalaliDateTimePicker from "@/components/JalaliDateTimePicker";

type Opt = { id: number; name?: string; code?: string };

export default function NewManovrForm({
  lines,
  trains,
  rahbaran,
  manovrTypes,
}: {
  lines: Opt[];
  trains: Opt[];
  rahbaran: Opt[];
  manovrTypes?: { code: number; label: string; isActive: boolean }[];
}) {
  const [state, action, pending] = useActionState(createManovr, null);
  const router = useRouter();

  return (
    <form action={action}>
      {state?.error && <div className="err">{state.error}</div>}

      <div className="field">
        <label htmlFor="type">نوع مانور *</label>
        <select id="type" name="type" className="input" defaultValue="">
          <option value="" disabled>انتخاب کنید…</option>
          {manovrTypes && manovrTypes.length > 0
            ? manovrTypes
                .filter((v) => v.isActive)
                .map((v) => (
                  <option key={v.code} value={v.code}>{v.label}</option>
                ))
            : Object.entries(ManovrType).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))
          }
        </select>
      </div>

      <div className="field">
        <label htmlFor="trainId">قطار *</label>
        <select id="trainId" name="trainId" className="input" defaultValue="">
          <option value="" disabled>انتخاب کنید…</option>
          {trains.map((t) => (
            <option key={t.id} value={t.id}>{t.code}</option>
          ))}
        </select>
      </div>

      <div className="grid2">
        <div className="field">
          <label htmlFor="sourceLineId">مبدأ</label>
          <select id="sourceLineId" name="sourceLineId" className="input" defaultValue="">
            <option value="">—</option>
            {lines.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor="destinationLineId">مقصد *</label>
          <select id="destinationLineId" name="destinationLineId" className="input" defaultValue="">
            <option value="" disabled>انتخاب کنید…</option>
            {lines.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid2">
        <div className="field">
          <label htmlFor="rahbar1Id">راهبر ۱ *</label>
          <select id="rahbar1Id" name="rahbar1Id" className="input" defaultValue="">
            <option value="" disabled>انتخاب کنید…</option>
            {rahbaran.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor="rahbar2Id">راهبر ۲ (کمکی)</label>
          <select id="rahbar2Id" name="rahbar2Id" className="input" defaultValue="">
            <option value="">—</option>
            {rahbaran.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="field">
        <label htmlFor="executionTime">زمان اجرای مانور *</label>
        <JalaliDateTimePicker
          name="executionTime"
          defaultValue={new Date().toISOString()}
          required
        />
      </div>

      <div className="field">
        <label htmlFor="description">توضیحات</label>
        <textarea id="description" name="description" className="input" rows={2} />
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
        <button className="btn accent" disabled={pending}>
          {pending ? "در حال ثبت…" : "ثبت مانور"}
        </button>
        <button type="button" className="btn" onClick={() => router.push("/manovrs")}>
          انصراف
        </button>
      </div>
    </form>
  );
}
