"use client";

import React, { useState, useTransition } from "react";
import { saveBrandingSettings } from "@/app/actions/lookups";

interface BrandingClientProps {
  initialSettings: {
    title: string;
    footer: string;
  };
}

export default function BrandingClient({ initialSettings }: BrandingClientProps) {
  const [title, setTitle] = useState(initialSettings.title);
  const [footer, setFooter] = useState(initialSettings.footer);
  const [isPending, startTransition] = useTransition();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const res = await saveBrandingSettings({ title, footer });
      if (res.ok) {
        alert("تنظیمات برندینگ با موفقیت ذخیره شد. لطفاً صفحه را رفرش کنید.");
      } else {
        alert(res.error || "خطا در ذخیره‌سازی");
      }
    });
  };

  return (
    <div style={{ maxWidth: "600px" }}>
      <form onSubmit={handleSubmit} className="card" style={{ padding: "24px", display: "flex", flexDirection: "column", gap: "20px" }}>
        <h3 style={{ fontSize: "16px", fontWeight: "bold", borderBottom: "1px solid var(--line)", paddingBottom: "10px" }}>
          شخصی‌سازی برندینگ و ظاهر سامانه
        </h3>

        <div>
          <label className="label">عنوان بالای سامانه (Header Title)</label>
          <input
            type="text"
            required
            className="input"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثال: سامانه مدیریت مانور"
          />
          <p className="muted" style={{ fontSize: "11px", marginTop: "4px" }}>
            این عنوان در سایدبار کناری و نوار مرورگر نمایش داده خواهد شد.
          </p>
        </div>

        <div>
          <label className="label">پانویس و امضا (Footer Text)</label>
          <input
            type="text"
            required
            className="input"
            value={footer}
            onChange={(e) => setFooter(e.target.value)}
            placeholder="مثال: پایانه فتح‌آباد · v3"
          />
          <p className="muted" style={{ fontSize: "11px", marginTop: "4px" }}>
            این متن در انتهای سایدبار کناری نقش می‌بندد.
          </p>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: "10px" }}>
          <button type="submit" disabled={isPending} className="btn primary">
            {isPending ? "در حال ذخیره‌سازی..." : "ذخیره تنظیمات برندینگ"}
          </button>
        </div>
      </form>
    </div>
  );
}
