"use client";

import React, { useState, useTransition } from "react";
import { triggerManualBackup, triggerSourceCodeBackup, deleteBackup, updateBackupSettings } from "@/app/actions/backup";

interface BackupRecord {
  id: number;
  filename: string;
  fileSize: number;
  backupType: string;
  schedule: string | null;
  createdAt: Date | string;
  dbExists: boolean;
  appExists: boolean;
}

interface BackupSettings {
  isEnabled: boolean;
  schedule: "daily" | "weekly" | "monthly";
  time: string;
}

export default function BackupClient({
  initialBackups,
  initialSettings,
  userRole,
}: {
  initialBackups: BackupRecord[];
  initialSettings: BackupSettings;
  userRole: number;
}) {
  const [backups, setBackups] = useState<BackupRecord[]>(initialBackups);
  const [settings, setSettings] = useState<BackupSettings>(initialSettings);
  const [isPending, startTransition] = useTransition();
  const [isBackupPending, setIsBackupPending] = useState(false);
  const [isCodeBackupPending, setIsCodeBackupPending] = useState(false);

  const isSuperAdmin = userRole === 4;

  // فرمت حجم فایل
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "۰ بایت";
    const k = 1024;
    const sizes = ["بایت", "کیلوبایت", "مگابایت", "گیگابایت"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    const val = parseFloat((bytes / Math.pow(k, i)).toFixed(2));
    return val.toLocaleString("fa-IR") + " " + sizes[i];
  };

  // فرمت تاریخ جلالی
  const formatDate = (dateStr: Date | string) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString("fa-IR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      calendar: "persian",
      timeZone: "Asia/Tehran",
    });
  };

  // ذخیره تنظیمات خودکار دیتابیس
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const res = await updateBackupSettings(settings);
      if (res.error) {
        alert(res.error);
      } else {
        alert("تنظیمات زمان‌بندی پشتیبان‌گیری با موفقیت ذخیره شد.");
      }
    });
  };

  // ایجاد پشتیبان دستی دیتابیس
  const handleCreateDbBackup = async () => {
    setIsBackupPending(true);
    try {
      const res = await triggerManualBackup();
      if (res.error) {
        alert(res.error);
      } else {
        alert("نسخه پشتیبان دیتابیس با موفقیت ایجاد شد.");
        window.location.reload();
      }
    } catch {
      alert("خطایی در سرور رخ داد.");
    } finally {
      setIsBackupPending(false);
    }
  };

  // ایجاد پشتیبان دستی سورس‌کد (فقط سوپرادمین)
  const handleCreateCodeBackup = async () => {
    setIsCodeBackupPending(true);
    try {
      const res = await triggerSourceCodeBackup();
      if (res.error) {
        alert(res.error);
      } else {
        alert("نسخه پشتیبان سورس‌کد با موفقیت ایجاد شد.");
        window.location.reload();
      }
    } catch {
      alert("خطایی در سرور رخ داد.");
    } finally {
      setIsCodeBackupPending(false);
    }
  };

  // حذف پشتیبان
  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف فیزیکی این نسخه پشتیبان مطمئن هستید؟ این عمل غیرقابل بازگشت است.")) return;

    const res = await deleteBackup(id);
    if (res.error) {
      alert(res.error);
    } else {
      setBackups((prev) => prev.filter((b) => b.id !== id));
      alert("نسخه پشتیبان با موفقیت حذف شد.");
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
      {/* ردیف بالا: تنظیمات خودکار و عملیات دستی */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "24px" }}>
        
        {/* کارت تنظیمات زمان‌بندی دیتابیس */}
        <div className="card" style={{ padding: "20px" }}>
          <div className="card-head" style={{ padding: "0 0 12px 0", borderBottom: "1px solid var(--line)" }}>
            <h2>🗓️ زمان‌بندی پشتیبان‌گیری خودکار دیتابیس</h2>
          </div>
          <form onSubmit={handleSaveSettings} style={{ display: "flex", flexDirection: "column", gap: "16px", marginTop: "16px" }}>
            
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <input
                type="checkbox"
                id="isEnabled"
                checked={settings.isEnabled}
                onChange={(e) => setSettings({ ...settings, isEnabled: e.target.checked })}
                style={{ width: "18px", height: "18px", accentColor: "var(--accent)" }}
              />
              <label htmlFor="isEnabled" style={{ fontWeight: 650, fontSize: "14px", cursor: "pointer" }}>
                فعال‌سازی پشتیبان‌گیری دوره‌ای دیتابیس
              </label>
            </div>

            {settings.isEnabled && (
              <>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  <label style={{ fontSize: "13px", color: "var(--ink-soft)" }}>دوره پشتیبان‌گیری:</label>
                  <select
                    value={settings.schedule}
                    onChange={(e) => setSettings({ ...settings, schedule: e.target.value as any })}
                    style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid var(--line)", background: "var(--panel)" }}
                  >
                    <option value="daily">روزانه (هر شب)</option>
                    <option value="weekly">هفتگی (هر جمعه شب)</option>
                    <option value="monthly">ماهانه (اول هر ماه)</option>
                  </select>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  <label style={{ fontSize: "13px", color: "var(--ink-soft)" }}>ساعت اجرای پشتیبان‌گیری:</label>
                  <input
                    type="time"
                    value={settings.time}
                    onChange={(e) => setSettings({ ...settings, time: e.target.value })}
                    style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid var(--line)", background: "var(--panel)" }}
                  />
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={isPending}
              className="btn primary"
              style={{ marginTop: "8px", width: "100%", justifyContent: "center" }}
            >
              {isPending ? "در حال ذخیره..." : "ذخیره تنظیمات زمان‌بندی"}
            </button>
          </form>
        </div>

        {/* کارت پشتیبان‌گیری دستی */}
        <div className="card" style={{ padding: "20px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <div>
            <div className="card-head" style={{ padding: "0 0 12px 0", borderBottom: "1px solid var(--line)" }}>
              <h2>⚡ عملیات پشتیبان‌گیری دستی</h2>
            </div>
            <p style={{ fontSize: "13px", color: "var(--ink-soft)", lineHeight: 1.8, marginTop: "16px" }}>
              از این بخش می‌توانید نسخه‌های پشتیبان دیتابیس و کدهای برنامه را به صورت دستی تهیه و ذخیره نمایید.
              <br />
              - <strong>پشتیبان دیتابیس</strong> شامل کلیه اطلاعات ثبت‌شده دیتابیس است و برای تمامی مدیران در دسترس است.
              {isSuperAdmin && (
                <>
                  <br />
                  - <strong>پشتیبان سورس‌کد</strong> شامل کدها و فایل‌های ساختاری برنامه است و فقط و منحصراً برای <strong>سوپرادمین</strong> مجاز می‌باشد.
                </>
              )}
            </p>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginTop: "16px" }}>
            <button
              onClick={handleCreateDbBackup}
              disabled={isBackupPending}
              className="btn primary"
              style={{ width: "100%", padding: "10px", justifyContent: "center", fontSize: "13px", gap: "6px" }}
            >
              {isBackupPending ? "در حال پشتیبان‌گیری دیتابیس..." : "🔄 ایجاد پشتیبان دیتابیس (SQLite)"}
            </button>

            {isSuperAdmin && (
              <button
                onClick={handleCreateCodeBackup}
                disabled={isCodeBackupPending}
                className="btn"
                style={{ width: "100%", padding: "10px", justifyContent: "center", fontSize: "13px", gap: "6px", border: "1px solid var(--accent)", color: "var(--accent)" }}
              >
                {isCodeBackupPending ? "در حال پشتیبان‌گیری سورس‌کد..." : "📦 ایجاد پشتیبان سورس‌کد (ZIP)"}
              </button>
            )}
          </div>
        </div>

      </div>

      {/* لیست فایل‌های بکاپ */}
      <div className="card" style={{ padding: "20px" }}>
        <div className="card-head" style={{ padding: "0 0 12px 0", borderBottom: "1px solid var(--line)" }}>
          <h2>📦 آرشیو فایل‌های پشتیبان سیستم</h2>
          <span className="spacer" />
          <span className="pill p-mut">{backups.length} نسخه</span>
        </div>

        <div style={{ marginTop: "16px", overflowX: "auto" }}>
          {backups.length === 0 ? (
            <div style={{ padding: "32px", textAlign: "center", color: "var(--ink-soft)" }}>
              <span style={{ fontSize: "36px" }}>📂</span>
              <p style={{ marginTop: "8px", fontSize: "14px" }}>هیچ فایل پشتیبانی ثبت نشده است.</p>
            </div>
          ) : (
            <table className="table" style={{ width: "100%", borderCollapse: "collapse", textAlign: "right" }}>
              <thead>
                <tr style={{ borderBottom: "2px solid var(--line)" }}>
                  <th style={{ padding: "12px" }}>شناسه</th>
                  <th style={{ padding: "12px" }}>تاریخ و زمان ایجاد</th>
                  <th style={{ padding: "12px" }}>نوع پشتیبان</th>
                  <th style={{ padding: "12px" }}>حجم فایل</th>
                  <th style={{ padding: "12px" }}>وضعیت روی دیسک</th>
                  <th style={{ padding: "12px", textAlign: "left" }}>دانلود و عملیات</th>
                </tr>
              </thead>
              <tbody>
                {backups.map((b) => {
                  const isCodeType = b.backupType === "source_code";
                  return (
                    <tr key={b.id} style={{ borderBottom: "1px solid var(--line-soft)" }}>
                      <td style={{ padding: "12px", fontFamily: "var(--mono)" }}>{b.id}</td>
                      <td style={{ padding: "12px" }}>{formatDate(b.createdAt)}</td>
                      <td style={{ padding: "12px" }}>
                        {isCodeType ? (
                          <span className="pill" style={{ backgroundColor: "var(--accent-soft)", color: "var(--accent-ink)", fontSize: "11px" }}>سورس‌کد</span>
                        ) : b.backupType === "manual" ? (
                          <span className="pill p-info" style={{ fontSize: "11px" }}>دستی (دیتابیس)</span>
                        ) : (
                          <span className="pill p-good" style={{ fontSize: "11px" }}>
                            خودکار ({b.schedule === "daily" ? "روزانه" : b.schedule === "weekly" ? "هفتگی" : "ماهانه"})
                          </span>
                        )}
                      </td>
                      <td style={{ padding: "12px" }}>{formatBytes(b.fileSize)}</td>
                      <td style={{ padding: "12px" }}>
                        {isCodeType ? (
                          <span className={`pill ${b.appExists ? "p-good" : "p-crit"}`} style={{ fontSize: "11px" }}>
                            سورس‌کد: {b.appExists ? "موجود ✅" : "حذف‌شده ❌"}
                          </span>
                        ) : (
                          <span className={`pill ${b.dbExists ? "p-good" : "p-crit"}`} style={{ fontSize: "11px" }}>
                            دیتابیس: {b.dbExists ? "موجود ✅" : "حذف‌شده ❌"}
                          </span>
                        )}
                      </td>
                      <td style={{ padding: "12px", textAlign: "left" }}>
                        <div style={{ display: "inline-flex", gap: "8px", alignItems: "center" }}>
                          
                          {/* دانلود دیتابیس */}
                          {!isCodeType && (
                            <a
                              href={b.dbExists ? `/api/admin/backups?id=${b.id}&type=db` : "#"}
                              onClick={(e) => !b.dbExists && e.preventDefault()}
                              className={`btn sm ${b.dbExists ? "" : "disabled"}`}
                              style={{
                                padding: "4px 8px",
                                fontSize: "11px",
                                backgroundColor: "var(--rail-soft)",
                                color: "var(--rail)",
                                opacity: b.dbExists ? 1 : 0.5,
                              }}
                              title="دانلود فایل دیتابیس sqlite"
                            >
                              📥 دانلود دیتابیس
                            </a>
                          )}

                          {/* دانلود سورس کد (فقط برای سوپرادمین و در صورت کد بودن بکاپ) */}
                          {isCodeType && isSuperAdmin && (
                            <a
                              href={b.appExists ? `/api/admin/backups?id=${b.id}&type=app` : "#"}
                              onClick={(e) => !b.appExists && e.preventDefault()}
                              className={`btn sm ${b.appExists ? "" : "disabled"}`}
                              style={{
                                padding: "4px 8px",
                                fontSize: "11px",
                                backgroundColor: "var(--accent-soft)",
                                color: "var(--accent)",
                                opacity: b.appExists ? 1 : 0.5,
                              }}
                              title="دانلود سورس کد zip"
                            >
                              📦 دانلود سورس‌کد
                            </a>
                          )}

                          {/* دکمه حذف */}
                          <button
                            onClick={() => handleDelete(b.id)}
                            className="btn sm"
                            style={{
                              padding: "4px 8px",
                              fontSize: "11px",
                              border: "1px solid var(--crit)",
                              color: "var(--crit)",
                              background: "transparent",
                            }}
                          >
                            🗑️ حذف
                          </button>

                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
