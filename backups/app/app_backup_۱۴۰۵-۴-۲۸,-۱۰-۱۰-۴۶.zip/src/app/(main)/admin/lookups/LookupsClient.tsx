"use client";

import React, { useState, useTransition } from "react";
import { saveLookupValue } from "@/app/actions/lookups";

interface LookupValue {
  id: number;
  code: number;
  label: string;
  color: string | null;
  icon: string | null;
  isActive: boolean;
  sortIdx: number;
}

interface LookupType {
  id: number;
  key: string;
  label: string;
  isSystem: boolean;
  values: LookupValue[];
}

interface LookupsClientProps {
  initialTypes: LookupType[];
}

export default function LookupsClient({ initialTypes }: LookupsClientProps) {
  const [types, setTypes] = useState<LookupType[]>(initialTypes);
  const [selectedTypeId, setSelectedTypeId] = useState<number>(initialTypes[0]?.id || 0);
  const [isPending, startTransition] = useTransition();

  const [editValue, setEditValue] = useState<Partial<LookupValue> | null>(null);
  const [isNew, setIsNew] = useState(false);

  const selectedType = types.find((t) => t.id === selectedTypeId);

  const handleEditClick = (val: LookupValue) => {
    setEditValue({ ...val });
    setIsNew(false);
  };

  const handleNewClick = () => {
    if (!selectedType) return;
    const maxCode = selectedType.values.reduce((max, v) => (v.code > max ? v.code : max), 0);
    const maxSort = selectedType.values.reduce((max, v) => (v.sortIdx > max ? v.sortIdx : max), 0);
    
    setEditValue({
      code: maxCode + 1,
      label: "",
      color: "#64748b",
      icon: "",
      isActive: true,
      sortIdx: maxSort + 1,
    });
    setIsNew(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedType || !editValue || editValue.code === undefined || !editValue.label) return;

    startTransition(async () => {
      const res = await saveLookupValue({
        typeId: selectedType.id,
        code: editValue.code!,
        label: editValue.label!,
        color: editValue.color ?? null,
        icon: editValue.icon ?? null,
        isActive: editValue.isActive ?? true,
        sortIdx: editValue.sortIdx ?? 0,
      });

      if (res.ok) {
        // به‌روزرسانی استیت محلی
        setTypes((prev) =>
          prev.map((t) => {
            if (t.id !== selectedType.id) return t;
            const exists = t.values.some((v) => v.code === editValue.code);
            const newValues = exists
              ? t.values.map((v) => (v.code === editValue.code ? (res.data as any) : v))
              : [...t.values, res.data as any];
            return {
              ...t,
              values: newValues.sort((a, b) => a.sortIdx - b.sortIdx),
            };
          })
        );
        setEditValue(null);
        alert("تغییرات با موفقیت ذخیره شد.");
      } else {
        alert(res.error || "خطا در ذخیره‌سازی");
      }
    });
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: "24px", alignItems: "start" }}>
      
      {/* سایدبار دسته‌بندی‌ها */}
      <div className="card" style={{ padding: "16px" }}>
        <h3 style={{ marginBottom: "16px", fontSize: "14px", fontWeight: "bold" }}>دسته‌بندی مقادیر</h3>
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          {types.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                setSelectedTypeId(t.id);
                setEditValue(null);
              }}
              className={`btn ${selectedTypeId === t.id ? "primary" : "outline"}`}
              style={{
                textAlign: "right",
                justifyContent: "flex-start",
                padding: "10px 14px",
                borderRadius: "8px",
                fontSize: "13px",
              }}
            >
              <span>📂 {t.label}</span>
              <span className="muted" style={{ fontSize: "10px", marginInlineStart: "auto" }}>
                ({t.values.length} مقدار)
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* بخش اصلی نمایش و ویرایش مقادیر */}
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        
        {selectedType && (
          <div className="card" style={{ padding: "20px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <div>
                <h2 style={{ fontSize: "18px", fontWeight: "bold" }}>مدیریت مقادیر: {selectedType.label}</h2>
                <p className="muted" style={{ fontSize: "12px", marginTop: "4px" }}>
                  کد ماشینی دسته: <code className="num">{selectedType.key}</code>
                </p>
              </div>
              <button onClick={handleNewClick} className="btn primary sm">
                ＋ افزودن مقدار جدید
              </button>
            </div>

            {/* جدول مقادیر */}
            <div className="table-w">
              <table>
                <thead>
                  <tr>
                    <th>کد (ID)</th>
                    <th>عنوان فارسی</th>
                    <th>رنگ نشان‌گر</th>
                    <th>ترتیب نمایش</th>
                    <th>وضعیت</th>
                    <th>اقدام</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedType.values.map((v) => (
                    <tr key={v.id} style={{ opacity: v.isActive ? 1 : 0.5 }}>
                      <td className="num">{v.code}</td>
                      <td>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          {v.color && (
                            <span 
                              style={{ 
                                width: "12px", 
                                height: "12px", 
                                borderRadius: "50%", 
                                backgroundColor: v.color,
                                border: "1px solid var(--line)"
                              }} 
                            />
                          )}
                          <b>{v.label}</b>
                        </div>
                      </td>
                      <td className="num">{v.color || "—"}</td>
                      <td className="num">{v.sortIdx}</td>
                      <td>
                        <span className={`pill ${v.isActive ? "p-good" : "p-mut"}`}>
                          {v.isActive ? "فعال" : "غیرفعال"}
                        </span>
                      </td>
                      <td>
                        <button 
                          onClick={() => handleEditClick(v)} 
                          className="btn sm outline"
                        >
                          ✏️ ویرایش
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* فرم افزودن / ویرایش */}
        {editValue && (
          <div className="card" style={{ padding: "20px", border: "1px solid var(--accent)" }}>
            <h3 style={{ fontSize: "15px", fontWeight: "bold", marginBottom: "16px" }}>
              {isNew ? "＋ افزودن مقدار جدید" : `✏️ ویرایش مقدار کد ${editValue.code}`}
            </h3>

            <form onSubmit={handleSave} style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
              <div>
                <label className="label">کد عددی (غیرقابل تغییر پس از ایجاد)</label>
                <input
                  type="number"
                  required
                  disabled={!isNew}
                  className="input num"
                  value={editValue.code ?? ""}
                  onChange={(e) => setEditValue((prev) => ({ ...prev, code: parseInt(e.target.value) || 0 }))}
                />
              </div>

              <div>
                <label className="label">عنوان فارسی</label>
                <input
                  type="text"
                  required
                  className="input"
                  value={editValue.label ?? ""}
                  onChange={(e) => setEditValue((prev) => ({ ...prev, label: e.target.value }))}
                />
              </div>

              <div>
                <label className="label">کد رنگ (Hex Code)</label>
                <div style={{ display: "flex", gap: "8px" }}>
                  <input
                    type="color"
                    style={{ width: "42px", height: "42px", padding: 0, border: "none", cursor: "pointer", borderRadius: "6px" }}
                    value={editValue.color ?? "#64748b"}
                    onChange={(e) => setEditValue((prev) => ({ ...prev, color: e.target.value }))}
                  />
                  <input
                    type="text"
                    className="input num"
                    placeholder="#ffffff"
                    value={editValue.color ?? ""}
                    onChange={(e) => setEditValue((prev) => ({ ...prev, color: e.target.value }))}
                  />
                </div>
              </div>

              <div>
                <label className="label">ترتیب نمایش (اولویت)</label>
                <input
                  type="number"
                  required
                  className="input num"
                  value={editValue.sortIdx ?? ""}
                  onChange={(e) => setEditValue((prev) => ({ ...prev, sortIdx: parseInt(e.target.value) || 0 }))}
                />
              </div>

              <div style={{ gridColumn: "span 2", display: "flex", alignItems: "center", gap: "10px", marginTop: "8px" }}>
                <input
                  type="checkbox"
                  id="isActive"
                  checked={editValue.isActive ?? true}
                  onChange={(e) => setEditValue((prev) => ({ ...prev, isActive: e.target.checked }))}
                />
                <label htmlFor="isActive" style={{ cursor: "pointer" }}>
                  <b>این مقدار فعال باشد و در منوها نشان داده شود.</b>
                  <p className="muted" style={{ fontSize: "11px", margin: 0 }}>
                    غیرفعالسازی نرم تضمین می‌کند که داده‌های تاریخی آسیب نبینند.
                  </p>
                </label>
              </div>

              <div style={{ gridColumn: "span 2", display: "flex", gap: "8px", justifyContent: "flex-end", marginTop: "12px" }}>
                <button 
                  type="button" 
                  onClick={() => setEditValue(null)} 
                  className="btn outline"
                >
                  انصراف
                </button>
                <button 
                  type="submit" 
                  disabled={isPending} 
                  className="btn primary"
                >
                  {isPending ? "در حال ذخیره‌سازی..." : "ذخیره تغییرات"}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
