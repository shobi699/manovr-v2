"use client";

import React from "react";
import DataTable from "@/components/DataTable";
import TrainRowActions from "./TrainRowActions";
import { TrainType } from "@/lib/enums";

import { updateTrainStatus, importTrainsFromExcel } from "@/app/actions/train";
import { useRouter } from "next/navigation";
import { useTransition } from "react";

interface TrainsTableClientProps {
  trains: any[];
  canManage: boolean;
}

export default function TrainsTableClient({ trains, canManage }: TrainsTableClientProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  const handleExportExcel = async () => {
    try {
      const ExcelJS = (await import("exceljs")).default;
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("لیست قطارها");
      worksheet.views = [{ rtl: true } as any];

      worksheet.columns = [
        { header: "کد قطار", key: "code", width: 15 },
        { header: "نوع قطار", key: "type", width: 15 },
        { header: "خط جاری", key: "lineName", width: 15 },
        { header: "وضعیت عملیاتی", key: "status", width: 20 },
        { header: "جایگاه پارک", key: "slotIndex", width: 15 },
        { header: "وضعیت سیستم", key: "isDisposed", width: 15 },
      ];

      trains.forEach((t) => {
        worksheet.addRow({
          code: t.code,
          type: TrainType[t.type] || t.type,
          lineName: t.line?.name || "—",
          status: t.status === 2 ? "تعمیرات" : t.status === 3 ? "غیرفعال" : t.status === 4 ? "در حال اعزام" : "آماده",
          slotIndex: t.slotIndex,
          isDisposed: t.isDisposed ? "غیرفعال" : "فعال",
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "trains-list.xlsx";
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);
      alert("خطا در خروجی گرفتن اکسل.");
    }
  };

  const handleDownloadSample = async () => {
    try {
      const ExcelJS = (await import("exceljs")).default;
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("نمونه ورود قطارها");
      worksheet.views = [{ rtl: true } as any];

      worksheet.columns = [
        { header: "کد قطار *", key: "code", width: 15 },
        { header: "نوع (0=AC مترویی، 1=DC دیزلی)", key: "type", width: 25 },
        { header: "وضعیت (1=آماده، 2=تعمیرات، 3=غیرفعال، 4=اعزام)", key: "status", width: 35 },
        { header: "نام خط پارک (مطابق خطوط تعریف شده)", key: "lineName", width: 30 },
        { header: "جایگاه پارک (عدد)", key: "slotIndex", width: 15 },
      ];

      worksheet.addRow({
        code: "101",
        type: 0,
        status: 1,
        lineName: "خط ۱ دپو",
        slotIndex: 1,
      });

      worksheet.addRow({
        code: "201",
        type: 1,
        status: 2,
        lineName: "تعمیرگاه ۵",
        slotIndex: 3,
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "trains-sample.xlsx";
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);
      alert("خطا در تولید فایل نمونه اکسل.");
    }
  };

  const handleExcelImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const arrayBuffer = event.target?.result as ArrayBuffer;
        const ExcelJS = (await import("exceljs")).default;
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(arrayBuffer);
        const worksheet = workbook.worksheets[0];

        const rows: any[] = [];
        worksheet.eachRow((row, rowNumber) => {
          if (rowNumber === 1) return;
          const vals = Array.isArray(row.values) ? row.values : [];
          
          const code = String(vals[1] || "").trim();
          if (!code) return;

          const type = vals[2] !== undefined ? Number(vals[2]) : undefined;
          const status = vals[3] !== undefined ? Number(vals[3]) : undefined;
          const lineName = vals[4] ? String(vals[4]).trim() : undefined;
          const slotIndex = vals[5] !== undefined ? Number(vals[5]) : undefined;

          rows.push({
            code,
            type,
            status,
            lineName,
            slotIndex,
          });
        });

        if (rows.length === 0) {
          alert("هیچ داده معتبری در فایل پیدا نشد.");
          return;
        }

        const res = await importTrainsFromExcel(rows);
        if (res.error) {
          alert(res.error);
        } else {
          alert(`تعداد ${res.count} قطار جدید با موفقیت درج شدند.`);
          window.location.reload();
        }
      } catch (err) {
        console.error(err);
        alert("فرمت فایل اکسل معتبر نیست یا خطا در خواندن رخ داد.");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const columns = [
    { key: "code", label: "کد قطار", sortable: true },
    {
      key: "type",
      label: "نوع قطار",
      sortable: true,
      render: (t: any) => (
        <span className={`pill ${t.type === 0 ? "p-rail" : "p-warn"}`}>
          {TrainType[t.type]}
        </span>
      ),
    },
    {
      key: "line",
      label: "خط جاری",
      sortable: true,
      render: (t: any) => t.line?.name ?? <span className="muted">—</span>,
    },
    {
      key: "opStatus",
      label: "وضعیت عملیاتی",
      sortable: true,
      render: (t: any) => {
        if (canManage) {
          return (
            <select
              value={t.status}
              className="input sm"
              style={{ padding: "4px 8px", fontSize: "12px", width: "140px", height: "32px" }}
              disabled={isPending}
              onChange={(e) => {
                const val = Number(e.target.value);
                startTransition(async () => {
                  const res = await updateTrainStatus(t.id, val);
                  if (res.error) {
                    alert(res.error);
                  } else {
                    router.refresh();
                  }
                });
              }}
            >
              <option value="1">🟢 آماده / استندبای</option>
              <option value="2">🛠️ تعمیرات</option>
              <option value="3">❌ غیرفعال</option>
              <option value="4">⚡ در حال اعزام</option>
            </select>
          );
        }

        return (
          <span style={{ fontSize: "12.5px", fontWeight: "600" }}>
            {t.status === 2 ? "🛠️ تعمیرات" :
             t.status === 3 ? "❌ غیرفعال" :
             t.status === 4 ? "⚡ در حال اعزام" : "🟢 آماده"}
          </span>
        );
      }
    },
    {
      key: "status",
      label: "وضعیت سیستم",
      sortable: true,
      render: (t: any) =>
        t.isDisposed ? (
          <span className="pill p-crit">غیرفعال</span>
        ) : (
          <span className="pill p-good">فعال</span>
        ),
    },
    ...(canManage
      ? [
          {
            key: "actions",
            label: "عملیات",
            render: (t: any) => <TrainRowActions id={t.id} />,
          },
        ]
      : []),
  ];

  return (
    <>
      {canManage && (
        <div className="card" style={{ padding: "16px", marginBottom: "20px", display: "flex", flexWrap: "wrap", gap: "12px", alignItems: "center" }}>
          <span style={{ fontWeight: 600, fontSize: "14px", color: "var(--ink)" }}>عملیات گروهی اکسل:</span>
          
          <button onClick={handleExportExcel} className="btn primary sm" style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <span style={{ fontSize: "16px" }}>📥</span> خروجی اکسل قطارها
          </button>
          
          <label className="btn sm" style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: "6px", margin: 0, padding: "8px 12px", border: "1px solid var(--line)" }}>
            <span style={{ fontSize: "16px" }}>📤</span> بارگذاری اکسل قطارها
            <input type="file" accept=".xlsx" onChange={handleExcelImport} style={{ display: "none" }} />
          </label>
          
          <button onClick={handleDownloadSample} className="btn sm" style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "transparent", border: "1px dashed var(--line)" }}>
            <span style={{ fontSize: "16px" }}>📄</span> دانلود نمونه اکسل ورودی
          </button>
        </div>
      )}

      <div className="card" style={{ padding: "16px" }}>
        <div className="card-head" style={{ padding: "0 0 12px 0", borderBottom: "1px solid var(--line)" }}>
        <h2>فهرست قطارها</h2>
        <span className="spacer" />
        <span className="pill p-mut">{trains.length}</span>
      </div>
      <div style={{ marginTop: "14px" }}>
        <DataTable
          tableName="trains"
          columns={columns}
          data={trains}
          searchPlaceholder="جستجو بر اساس کد قطار..."
          searchFields={["code"]}
        />
      </div>
    </div>
  </>
  );
}
