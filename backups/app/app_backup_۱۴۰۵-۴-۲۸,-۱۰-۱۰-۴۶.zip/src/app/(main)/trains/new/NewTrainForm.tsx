"use client";

import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { createTrain } from "@/app/actions/train";
import { TrainType } from "@/lib/enums";

type LineOpt = { id: number; name: string };

export default function NewTrainForm({ lines }: { lines: LineOpt[] }) {
  const [state, action, pending] = useActionState(createTrain, null);
  const router = useRouter();

  return (
    <form action={action}>
      {state?.error && <div className="err">{state.error}</div>}

      <div className="grid2">
        <div className="field">
          <label htmlFor="code">کد قطار *</label>
          <input id="code" name="code" className="input" autoFocus />
        </div>
        <div className="field">
          <label htmlFor="type">نوع *</label>
          <select id="type" name="type" className="input" defaultValue="0">
            {Object.entries(TrainType).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="field">
        <label htmlFor="lineId">خط فعلی</label>
        <select id="lineId" name="lineId" className="input" defaultValue="">
          <option value="">بدون خط</option>
          {lines.map((l) => (
            <option key={l.id} value={l.id}>{l.name}</option>
          ))}
        </select>
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
        <button className="btn accent" disabled={pending}>
          {pending ? "در حال ثبت…" : "ثبت قطار"}
        </button>
        <button type="button" className="btn" onClick={() => router.push("/trains")}>
          انصراف
        </button>
      </div>
    </form>
  );
}
