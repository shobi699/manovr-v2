import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { hasPerm } from "@/lib/perms";
import { redirect, notFound } from "next/navigation";
import EditTrainForm from "./EditTrainForm";

export default async function EditTrainPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await getSession();
  if (!session || !(await hasPerm(session, "train.manage"))) redirect("/trains");

  const { id } = await params;
  const train = await prisma.train.findUnique({ where: { id: Number(id) } });
  if (!train) notFound();

  const lines = await prisma.line.findMany({
    orderBy: { name: "asc" },
    select: { id: true, name: true },
  });

  return (
    <>
      <div className="topbar"><h1>ویرایش قطار: {train.code}</h1></div>
      <div className="content">
        <div className="card">
          <div className="card-body">
            <EditTrainForm
              train={{ id: train.id, code: train.code, type: train.type, lineId: train.lineId, isDisposed: train.isDisposed }}
              lines={lines}
            />
          </div>
        </div>
      </div>
    </>
  );
}
