"use client";

import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { updateTrain } from "@/app/actions/train";
import { TrainType } from "@/lib/enums";

type LineOpt = { id: number; name: string };
type Train = { id: number; code: string; type: number; lineId: number | null; isDisposed: boolean };

export default function EditTrainForm({ train, lines }: { train: Train; lines: LineOpt[] }) {
  const [state, action, pending] = useActionState(updateTrain, null);
  const router = useRouter();

  return (
    <form action={action}>
      <input type="hidden" name="id" value={train.id} />
      {state?.error && <div className="err">{state.error}</div>}

      <div className="grid2">
        <div className="field">
          <label htmlFor="code">کد قطار *</label>
          <input id="code" name="code" className="input" defaultValue={train.code} autoFocus />
        </div>
        <div className="field">
          <label htmlFor="type">نوع *</label>
          <select id="type" name="type" className="input" defaultValue={train.type}>
            {Object.entries(TrainType).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid2">
        <div className="field">
          <label htmlFor="lineId">خط فعلی</label>
          <select id="lineId" name="lineId" className="input" defaultValue={train.lineId ?? ""}>
            <option value="">بدون خط</option>
            {lines.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor="isDisposed">وضعیت</label>
          <select id="isDisposed" name="isDisposed" className="input" defaultValue={train.isDisposed ? "1" : "0"}>
            <option value="0">فعال</option>
            <option value="1">غیرفعال</option>
          </select>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
        <button className="btn accent" disabled={pending}>
          {pending ? "در حال ذخیره…" : "ذخیره تغییرات"}
        </button>
        <button type="button" className="btn" onClick={() => router.push("/trains")}>
          انصراف
        </button>
      </div>
    </form>
  );
}
