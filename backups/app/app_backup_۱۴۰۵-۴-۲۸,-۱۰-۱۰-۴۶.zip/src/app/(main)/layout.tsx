import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import Sidebar from "@/components/Sidebar";

export default async function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();
  if (!session) redirect("/login");
  return (
    <div className="shell">
      <Sidebar userId={session.id} fullName={session.fullName} role={session.role} />
      <main className="main">{children}</main>
    </div>
  );
}
