"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { hasPerm } from "@/lib/perms";
import { audit } from "@/lib/audit";

export async function createManovr(
  _prev: { error?: string } | null,
  fd: FormData
): Promise<{ error?: string }> {
  const session = await getSession();
  if (!session) return { error: "ابتدا وارد شوید." };
  if (!(await hasPerm(session, "manovr.create")))
    return { error: "دسترسی ندارید. شما اجازه ثبت مانور را ندارید." };

  const type = Number(fd.get("type"));
  const trainId = Number(fd.get("trainId"));
  const destinationLineId = Number(fd.get("destinationLineId"));
  const sourceRaw = fd.get("sourceLineId");
  const sourceLineId = sourceRaw ? Number(sourceRaw) : null;
  const rahbar1Id = Number(fd.get("rahbar1Id"));
  const rahbar2Raw = fd.get("rahbar2Id");
  const rahbar2Id = rahbar2Raw ? Number(rahbar2Raw) : null;
  const slotIndex = fd.get("slotIndex") ? Number(fd.get("slotIndex")) : 0;
  const description = String(fd.get("description") ?? "").trim() || null;
  const executionTimeRaw = fd.get("executionTime");
  const executionTime = executionTimeRaw ? new Date(String(executionTimeRaw)) : new Date();

  if (!type) return { error: "لطفا نوع مانور را انتخاب کنید." };
  if (!trainId) return { error: "لطفا قطار را انتخاب نمایید." };
  if (!destinationLineId) return { error: "لطفا مقصد را انتخاب نمایید." };
  if (!rahbar1Id) return { error: "لطفا راهبر ۱ را انتخاب نمایید." };

  // بررسی ظرفیت خط مقصد
  const dest = await prisma.line.findUnique({ where: { id: destinationLineId } });
  if (!dest) return { error: "خط مقصد نامعتبر است." };
  const onDest = await prisma.train.count({ where: { lineId: destinationLineId, isDisposed: false } });
  if (onDest >= dest.capacity)
    return { error: "ظرفیت خط مقصد پر شده است." };

  const created = await prisma.manovr.create({
    data: {
      type,
      status: 1,
      confirmationStatus: 3,
      description,
      sourceLineId,
      destinationLineId,
      trainId,
      rahbar1Id,
      rahbar2Id,
      creatorId: session.id,
      executionTime,
    },
    include: {
      train: true,
      sourceLine: true,
      destinationLine: true,
    }
  });

  // جابجایی قطار به خط و اسلات مقصد
  await prisma.train.update({
    where: { id: trainId },
    data: { lineId: destinationLineId, slotIndex },
  });

  // ثبت لاگ وقایع
  const trainCode = created.train?.code || String(trainId);
  const srcName = created.sourceLine?.name || "نامشخص";
  const destName = created.destinationLine?.name || "نامشخص";
  await audit(
    session,
    "manovr",
    created.id,
    "CREATE",
    null,
    created,
    `مانور جدیدی برای قطار ${trainCode} از خط ${srcName} به خط ${destName} ثبت گردید.`
  );

  revalidatePath("/manovrs");
  revalidatePath("/dashboard");
  revalidatePath("/depot");
  redirect("/manovrs");
}

export async function finishManovr(id: number) {
  const session = await getSession();
  if (!session || !(await hasPerm(session, "manovr.edit"))) return { error: "دسترسی ندارید." };

  const before = await prisma.manovr.findUnique({ where: { id } });
  const after = await prisma.manovr.update({
    where: { id },
    data: { status: 2, finishedAt: new Date() },
  });

  await audit(
    session,
    "manovr",
    id,
    "UPDATE",
    before,
    after,
    `مانور شماره ${id} خاتمه یافته و با موفقیت بسته شد.`
  );

  revalidatePath("/manovrs");
  revalidatePath("/dashboard");
  revalidatePath("/depot");
  return { ok: true };
}

export async function confirmManovr(id: number, value: number) {
  const session = await getSession();
  if (!session || !(await hasPerm(session, "manovr.confirm"))) return { error: "دسترسی ندارید." };

  const before = await prisma.manovr.findUnique({ where: { id } });
  const after = await prisma.manovr.update({
    where: { id },
    data: { confirmationStatus: value },
  });

  const word = value === 1 ? "تأیید" : "رد";
  await audit(
    session,
    "manovr",
    id,
    "CONFIRM",
    before,
    after,
    `سند مانور شماره ${id} توسط مسئول شیفت ${word} گردید.`
  );

  revalidatePath("/manovrs");
  revalidatePath("/dashboard");
  revalidatePath("/depot");
  return { ok: true };
}

export async function deleteManovr(id: number) {
  const session = await getSession();
  if (!session || !(await hasPerm(session, "manovr.delete"))) return { error: "دسترسی ندارید." };

  const before = await prisma.manovr.findUnique({ where: { id } });
  const after = await prisma.manovr.update({ where: { id }, data: { status: 3 } });

  await audit(
    session,
    "manovr",
    id,
    "DELETE",
    before,
    after,
    `سند مانور شماره ${id} به صورت نرم از سیستم حذف گردید.`
  );

  revalidatePath("/manovrs");
  revalidatePath("/dashboard");
  revalidatePath("/depot");
  return { ok: true };
}
