"use server";

import { revalidatePath } from "next/cache";
import fs from "fs";
import path from "path";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { hasPerm } from "@/lib/perms";
import { performBackup, performSourceCodeBackup } from "@/lib/backup";
import { audit } from "@/lib/audit";

/**
 * بررسی دسترسی ادمین/مدیر پشتیبان‌گیری (شامل ادمین ۱، سرپرست ۲ با دسترسی تنظیمات و سوپرادمین ۴)
 */
async function checkAuth() {
  const session = await getSession();
  if (!session) return false;
  if (session.role === 1 || session.role === 4) return true; // ادمین کل سیستم یا سوپرادمین
  return await hasPerm(session, "settings.global");
}

/**
 * بررسی دسترسی اختصاصی سوپرادمین (نقش ۴)
 */
async function checkSuperAdmin() {
  const session = await getSession();
  return session?.role === 4;
}

/**
 * دریافت لیست نسخه‌های پشتیبان (مدیر فقط دیتابیس را می‌بیند، سوپرادمین همه را)
 */
export async function getBackupsList() {
  const session = await getSession();
  if (!session || (session.role !== 1 && session.role !== 4 && !(await hasPerm(session, "settings.global")))) {
    throw new Error("دسترسی غیرمجاز");
  }

  const isSuper = session.role === 4;

  const list = await prisma.backup.findMany({
    where: isSuper ? {} : { backupType: { not: "source_code" } },
    orderBy: { createdAt: "desc" },
  });

  // بررسی وضعیت وجود فیزیکی فایل‌ها روی دیسک
  return list.map((b) => {
    let filePaths;
    try {
      filePaths = JSON.parse(b.filePath);
    } catch {
      filePaths = { db: "", app: "" };
    }

    const dbExists = filePaths.db ? fs.existsSync(filePaths.db) : false;
    const appExists = filePaths.app ? fs.existsSync(filePaths.app) : false;

    return {
      ...b,
      dbExists,
      appExists,
    };
  });
}

/**
 * شروع پشتیبان‌گیری دیتابیس (توسط ادمین یا سوپرادمین)
 */
export async function triggerManualBackup() {
  if (!(await checkAuth())) {
    return { error: "دسترسی غیرمجاز" };
  }

  try {
    const backup = await performBackup("manual");
    revalidatePath("/admin/backup");
    return { ok: true, id: backup.id };
  } catch (err: any) {
    console.error(err);
    return { error: err.message || "خطا در ایجاد نسخه پشتیبان دیتابیس" };
  }
}

/**
 * شروع پشتیبان‌گیری سورس‌کد (منحصراً توسط سوپرادمین)
 */
export async function triggerSourceCodeBackup() {
  if (!(await checkSuperAdmin())) {
    return { error: "دسترسی غیرمجاز. فقط سوپرادمین می‌تواند پشتیبان سورس‌کد تهیه کند." };
  }

  try {
    const backup = await performSourceCodeBackup();
    revalidatePath("/admin/backup");
    return { ok: true, id: backup.id };
  } catch (err: any) {
    console.error(err);
    return { error: err.message || "خطا در ایجاد نسخه پشتیبان سورس‌کد" };
  }
}

/**
 * حذف فیزیکی و دیتابیسی نسخه پشتیبان
 */
export async function deleteBackup(id: number) {
  const session = await getSession();
  const isSuper = session?.role === 4;
  const isNormalAdmin = session?.role === 1 || (session && await hasPerm(session, "settings.global"));

  if (!session || (!isSuper && !isNormalAdmin)) {
    return { error: "دسترسی غیرمجاز" };
  }

  try {
    const backup = await prisma.backup.findUnique({ where: { id } });
    if (!backup) return { error: "پشتیبان یافت نشد" };

    // ممانعت از حذف سورس‌کد توسط غیر از سوپرادمین
    if (backup.backupType === "source_code" && !isSuper) {
      return { error: "دسترسی غیرمجاز. فقط سوپرادمین مجاز به حذف فایل سورس‌کد است." };
    }

    let filePaths;
    try {
      filePaths = JSON.parse(backup.filePath);
    } catch {
      filePaths = { db: "", app: "" };
    }

    // حذف فیزیکی فایل‌ها
    if (filePaths.db && fs.existsSync(filePaths.db)) fs.unlinkSync(filePaths.db);
    if (filePaths.app && fs.existsSync(filePaths.app)) fs.unlinkSync(filePaths.app);

    // حذف از دیتابیس
    await prisma.backup.delete({ where: { id } });

    // ثبت در لاگ سیستم
    await audit(
      null,
      "backup",
      id,
      "DELETE",
      null,
      {},
      `نسخه پشتیبان به شماره شناسه ${id} حذف شد.`
    );

    revalidatePath("/admin/backup");
    return { ok: true };
  } catch (err: any) {
    console.error(err);
    return { error: err.message || "خطا در حذف نسخه پشتیبان" };
  }
}

/**
 * دریافت تنظیمات زمان‌بندی پشتیبان‌گیری
 */
export async function getBackupSettings() {
  if (!(await checkAuth())) {
    throw new Error("دسترسی غیرمجاز");
  }

  const setting = await prisma.appSetting.findUnique({
    where: { scope_userId_key: { scope: "global", userId: 0, key: "backup_config" } },
  });

  if (!setting) {
    return {
      isEnabled: false,
      schedule: "daily",
      time: "02:00",
    };
  }

  try {
    return JSON.parse(setting.value);
  } catch {
    return {
      isEnabled: false,
      schedule: "daily",
      time: "02:00",
    };
  }
}

/**
 * بروزرسانی تنظیمات زمان‌بندی پشتیبان‌گیری
 */
export async function updateBackupSettings(data: {
  isEnabled: boolean;
  schedule: "daily" | "weekly" | "monthly";
  time: string;
}) {
  if (!(await checkAuth())) {
    return { error: "دسترسی غیرمجاز" };
  }

  try {
    await prisma.appSetting.upsert({
      where: { scope_userId_key: { scope: "global", userId: 0, key: "backup_config" } },
      create: {
        scope: "global",
        userId: 0,
        key: "backup_config",
        value: JSON.stringify(data),
      },
      update: {
        value: JSON.stringify(data),
      },
    });

    // ثبت در لاگ سیستم
    await audit(
      null,
      "backup_config",
      0,
      "UPDATE",
      null,
      data,
      `تنظیمات زمان‌بندی پشتیبان‌گیری بروزرسانی شد: وضعیت ${data.isEnabled ? 'فعال' : 'غیرفعال'}، دوره ${data.schedule}، ساعت ${data.time}`
    );

    revalidatePath("/admin/backup");
    return { ok: true };
  } catch (err: any) {
    console.error(err);
    return { error: err.message || "خطا در ذخیره تنظیمات" };
  }
}
