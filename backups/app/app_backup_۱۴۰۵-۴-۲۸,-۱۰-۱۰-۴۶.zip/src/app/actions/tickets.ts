"use server";

import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { hasPerm } from "@/lib/perms";
import { emitSSEEvent } from "@/lib/events";

// ۱. ارسال پیام عمومی/خصوصی توسط مدیر (Broadcast & Direct Message)
export async function sendAdminMessage(data: {
  title: string;
  body: string;
  kind: "info" | "success" | "warning" | "alert";
  targetUserId?: number | null; // نال یعنی ارسال همگانی
}) {
  const session = await getSession();
  if (!session || !(await hasPerm(session, "settings.global"))) {
    return { ok: false, error: "عدم دسترسی کافی (فقط مدیر سیستم)" };
  }

  try {
    if (data.targetUserId) {
      // ارسال پیام به یک کاربر مشخص
      const notif = await prisma.notification.create({
        data: {
          userId: Number(data.targetUserId),
          kind: data.kind,
          title: data.title,
          body: data.body,
        },
      });
      emitSSEEvent("notification_new", { userId: notif.userId });
    } else {
      // ارسال پیام همگانی (به تمام پرسنل فعال)
      const allPersonnel = await prisma.personnel.findMany({
        select: { id: true },
      });

      const notifsData = allPersonnel.map((p) => ({
        userId: p.id,
        kind: data.kind,
        title: data.title,
        body: data.body,
      }));

      await prisma.notification.createMany({
        data: notifsData,
      });

      emitSSEEvent("notification_new", { broadcast: true });
    }

    return { ok: true };
  } catch (error: any) {
    return { ok: false, error: error.message || "خطا در ارسال پیام" };
  }
}

// ۲. ایجاد تیکت پشتیبانی جدید توسط هر کاربر
export async function createTicket(title: string, body: string) {
  const session = await getSession();
  if (!session) return { ok: false, error: "کاربر احراز هویت نشده است" };

  try {
    const ticket = await prisma.ticket.create({
      data: {
        title,
        body,
        status: "open",
        creatorId: session.id,
      },
    });

    // ثبت اعلان برای مدیران در خصوص ثبت تیکت جدید
    const admins = await prisma.personnel.findMany({
      where: { role: 1 },
      select: { id: true },
    });

    const notifs = admins.map((admin) => ({
      userId: admin.id,
      kind: "info" as const,
      title: `تیکت جدید: ${title}`,
      body: `یک تیکت عملیاتی جدید توسط ${session.fullName} ثبت گردید.`,
      link: "/dashboard",
    }));

    if (notifs.length > 0) {
      await prisma.notification.createMany({ data: notifs });
      emitSSEEvent("notification_new", { role: 1 });
    }

    emitSSEEvent("ticket_changed", { ticketId: ticket.id });
    return { ok: true, data: ticket };
  } catch (error: any) {
    return { ok: false, error: error.message || "خطا در ثبت تیکت" };
  }
}

// ۳. دریافت لیست تیکت‌ها (مدیر کل تیکت‌ها را می‌بیند، کاربر فقط تیکت‌های خودش را)
export async function getTicketsList() {
  const session = await getSession();
  if (!session) return { ok: false, error: "کاربر احراز هویت نشده است" };

  const isManager = session.role === 1 || session.role === 2 || session.role === 4;

  try {
    const tickets = await prisma.ticket.findMany({
      where: isManager ? {} : { creatorId: session.id },
      orderBy: { createdAt: "desc" },
      include: {
        creator: {
          select: { id: true, firstName: true, lastName: true },
        },
        replies: {
          orderBy: { createdAt: "asc" },
        },
      },
    });

    return { ok: true, data: tickets };
  } catch (error: any) {
    return { ok: false, error: error.message || "خطا در دریافت لیست تیکت‌ها" };
  }
}

// ۴. ارسال پاسخ به تیکت
export async function replyToTicket(ticketId: number, body: string) {
  const session = await getSession();
  if (!session) return { ok: false, error: "کاربر احراز هویت نشده است" };

  try {
    const ticket = await prisma.ticket.findUnique({
      where: { id: ticketId },
      include: { creator: true },
    });
    if (!ticket) return { ok: false, error: "تیکت یافت نشد" };

    const reply = await prisma.ticketReply.create({
      data: {
        ticketId,
        body,
        userId: session.id,
      },
    });

    // در صورتی که پاسخ‌دهنده شخص دیگری (مثل مدیر) باشد، برای سازنده تیکت اعلان بفرست
    if (ticket.creatorId !== session.id) {
      await prisma.notification.create({
        data: {
          userId: ticket.creatorId,
          kind: "success",
          title: "پاسخ جدید به تیکت شما",
          body: `پاسخ جدیدی برای تیکت "${ticket.title}" ثبت شد.`,
          link: "/dashboard",
        },
      });
      emitSSEEvent("notification_new", { userId: ticket.creatorId });
    }

    await prisma.ticket.update({
      where: { id: ticketId },
      data: { status: "open", updatedAt: new Date() }, // بازگشت وضعیت به باز در صورت پاسخ کاربر
    });

    emitSSEEvent("ticket_changed", { ticketId });
    return { ok: true, data: reply };
  } catch (error: any) {
    return { ok: false, error: error.message || "خطا در ثبت پاسخ" };
  }
}

// ۵. بستن یا حل تیکت
export async function updateTicketStatus(ticketId: number, status: "resolved" | "closed" | "open") {
  const session = await getSession();
  if (!session) return { ok: false, error: "کاربر احراز هویت نشده است" };

  try {
    const ticket = await prisma.ticket.findUnique({
      where: { id: ticketId },
    });
    if (!ticket) return { ok: false, error: "تیکت یافت نشد" };

    // بررسی دسترسی: فقط سازنده تیکت یا مدیران می‌توانند وضعیت آن را تغییر دهند
    const isManager = session.role === 1 || session.role === 2 || session.role === 4;
    if (ticket.creatorId !== session.id && !isManager) {
      return { ok: false, error: "عدم دسترسی کافی" };
    }

    const updated = await prisma.ticket.update({
      where: { id: ticketId },
      data: { status },
    });

    // ثبت اعلان برای سازنده تیکت اگر مدیر آن را ببندد
    if (ticket.creatorId !== session.id) {
      await prisma.notification.create({
        data: {
          userId: ticket.creatorId,
          kind: "info",
          title: "تغییر وضعیت تیکت",
          body: `وضعیت تیکت "${ticket.title}" به ${status === "resolved" ? "حل شده" : "بسته شده"} تغییر یافت.`,
        },
      });
      emitSSEEvent("notification_new", { userId: ticket.creatorId });
    }

    emitSSEEvent("ticket_changed", { ticketId });
    return { ok: true, data: updated };
  } catch (error: any) {
    return { ok: false, error: error.message || "خطا در تغییر وضعیت تیکت" };
  }
}
