// سیستم مجوزهای ریز — جایگزین تدریجی نقش‌های عددی
import { prisma } from "@/lib/prisma";
import type { Session } from "@/lib/auth";

export const ALL_PERMS = [
  "manovr.create", "manovr.edit", "manovr.confirm", "manovr.delete",
  "train.manage", "line.manage", "user.manage", "role.manage",
  "report.build", "report.export", "report.import",
  "settings.global", "depot.layout", "phonebook.edit",
] as const;

export type Perm = (typeof ALL_PERMS)[number];

export const PERM_LABELS: Record<Perm, string> = {
  "manovr.create": "ثبت مانور",
  "manovr.edit": "ویرایش مانور",
  "manovr.confirm": "تأیید/رد مانور",
  "manovr.delete": "حذف مانور",
  "train.manage": "مدیریت قطارها",
  "line.manage": "مدیریت خطوط",
  "user.manage": "مدیریت کاربران",
  "role.manage": "مدیریت نقش‌ها",
  "report.build": "ساخت گزارش",
  "report.export": "خروجی گزارش",
  "report.import": "ایمپورت داده",
  "settings.global": "تنظیمات سراسری",
  "depot.layout": "چیدمان پایانه",
  "phonebook.edit": "ویرایش دفتر تلفن",
};

// مجوزهای معادل نقش‌های قدیمی (fallback وقتی accessRole ندارد)
const LEGACY: Record<number, string[]> = {
  4: [...ALL_PERMS],
  1: [...ALL_PERMS],
  2: ["manovr.create", "manovr.edit", "manovr.confirm", "manovr.delete", "report.build", "report.export", "settings.global"],
  3: ["report.build", "report.export"],
  0: [],
};

// مجوزهای مؤثر کاربر را از DB می‌خواند (accessRole یا fallback نقش قدیمی)
export async function getUserPerms(userId: number, legacyRole: number): Promise<string[]> {
  const p = await prisma.personnel.findUnique({
    where: { id: userId },
    include: { accessRole: true },
  });
  if (p?.accessRole) {
    try { return JSON.parse(p.accessRole.permissions); } catch { /* fallthrough */ }
  }
  return LEGACY[p?.role ?? legacyRole] ?? [];
}

export function permsInclude(perms: string[], perm: Perm) {
  return perms.includes(perm);
}

// چک مجوز برای server action ها — session.perms اگر در JWT باشد، وگرنه DB
export async function hasPerm(session: Session | null, perm: Perm): Promise<boolean> {
  if (!session) return false;
  if (session.perms) return session.perms.includes(perm);
  const perms = await getUserPerms(session.id, session.role);
  return perms.includes(perm);
}
